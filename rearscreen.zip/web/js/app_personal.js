/* ============================================================================
   东海帝皇 — 三渲二 · Q 弹骨骼 (小米 17 Pro 背屏 / WebView + Three.js)
   - 镜头对准模型正面「上半身」区域
   - 可互动骨骼：Ear_01_L / Ear_01_R（耳链根骨骼，按住拖动 = 有限距离拉伸拖拽；
     松手 = 布丁弹簧回弹抖动，拉得越远回弹越猛）
   - 物理骨骼：耳朵 / 头发 / 尾巴 / 衣服（Ribbon、Mantle、Hood、Bust、Skirt、Sleeve）
     全部走同一套「尾端质点 + 长度约束 + 偏角限制」弹簧链：
       · 静止目标由「父骨骼当前世界矩阵 × 静止局部变换」算出 → 父级一动，惯性逐级往链尾传
       · 陀螺仪重力（g·grav）直接加在质点上，倾哪边甩哪边
       · 末节骨骼的虚拟尾长按蒙皮顶点自动估算，长短发片/裙摆各拿各的力臂
     互动耳 = 链首骨骼：拖拽改它的位移，物理改它的朝向，互不冲突。
   - 陀螺仪三路兜底：deviceorientationabsolute / deviceorientation / devicemotion，
     按「通道活跃度」每帧挑选——谁断流超过 700ms 就让位给还活着的通道，
     断流超过 2.2s 回来时自动重取中立位；三路全没有时退化成指针位置模拟。
     __gyro() 可查看当前走的哪一路、各通道最后一次数据的年龄。
   - 黑底 + 一盏主光 + toon 卡通着色 + 反向外壳黑色描边
   ========================================================================== */
(function () {
  'use strict';

  // ----------------------------- 可调参数 -----------------------------
  var MAX_PULL   = 0.115;  // 单根互动骨骼最大拉伸距离（模型单位）
  var GRAB_PX    = 52;     // 命中耳朵的屏幕半径（CSS px）：到「耳骨链屏幕折线」的距离
  var SPRING_K   = 170.0;  // 互动骨骼回弹刚度（越大回弹越快）
  var SPRING_C   = 8.2;    // 互动骨骼阻尼（越小抖得越久越 Q 弹）
  var NONLINEAR  = 0.9;    // 非线性项：拉得越远等效刚度越大 → 回弹更猛
  var VEL_CLAMP  = 7.0;    // 释放瞬间估算速度上限，防止爆裂

  var PHY_GRAV   = 5.6;    // 陀螺仪重力强度（所有物理骨骼共用的总增益）
  var PHY_TIP_L  = 0.055;  // 末节骨骼的虚拟尾长（估算失败时的兜底值）
  var IDLE_SWAY  = 0.10;   // 完全静止时的微弱呼吸摆动（会同时吹动头发/衣摆）

  var OUTLINE_W  = 0.0022; // 描边宽度（世界单位，会随相机距离缩放）
  var FOV        = 30;     // 相机竖直视场角
  var FIT        = 1.02;   // 相机框定松紧（越大模型越小）
  var FRAME_BTM  = 0.17;   // 取景下沿：裁掉身高下面 17% → 头肩胸，即「上半身」
  var FRAME_TOP  = 0.10;   // 取景上沿额外留白（占身高比例），留给耳朵甩动
  var FRAME_HALF = 0.34;   // 取景横向至少 ±34% 身高，保证不左右裁切

  // 可互动骨骼（拖拽手柄）= 耳链的根骨骼
  var INTERACTIVE = ['Ear_01_L', 'Ear_01_R'];

  /* ---------- 物理骨骼（全部走同一套「尾端质点 + 长度约束」弹簧链）----------
     每条链写成 [参数, [父…子]]，父子必须相连。
       k    : 回正刚度（越大越硬、甩幅越小、抖得越快）
       c    : 阻尼（越小越 Q 弹、余振越久）
       grav : 受重力（陀螺仪）影响的权重，重的部件（裙摆）给小一点
       max  : 相对静止姿态的最大偏角（度），防止甩过头穿进身体/翻面
     末节骨骼的「虚拟尾长」会按蒙皮顶点自动估算，不用逐根手填。 */
  var EAR    = { grp: 'ear',   k: 160, c: 8.5,  grav: 0.50, max: 25 };
  var HAIR   = { grp: 'hair',  k: 330, c: 12.0, grav: 0.90, max: 38 };
  var TAIL   = { grp: 'tail',  k: 280, c: 10.0, grav: 0.90, max: 44 };
  var CLOTH  = { grp: 'cloth', k: 330, c: 15.0, grav: 0.75, max: 22 };
  var SKIRT  = { grp: 'skirt', k: 380, c: 16.0, grav: 0.65, max: 18 };
  var SLEEVE = { grp: 'cloth', k: 420, c: 16.0, grav: 0.50, max: 14 };

  /* ---------- 物理链：按加载后的骨架「名称模式」自动构建 ----------
     东海帝皇（Tokai Teio）与案例曼波的骨骼链 / 骨骼名不完全一致
     （例如尾巴是 Sp_Hi_Tail0_B_* + しっぽ、袖子是 Sp_Ar_Mantle*、衣服是 Sp_Ch_Mantle1_*），
     但物理骨骼的命名前缀高度相似，因此这里不再写死每根链，而是按名称模式分组、
     从「父级不是同组骨骼」的根向叶遍历自动生成链，换模型通常只需微调 kindOf。 */
  var PHY_ENABLE = { ear: true, hair: true, tail: true, cloth: true, skirt: true };

  // 骨骼名 -> 物理分组（ear / hair / tail / cloth / sleeve / skirt）
  function kindOf(name) {
    if (/^Ear_0\d_[LR]$/i.test(name)) return 'ear';
    if (/^Sp_He_Hair/i.test(name))    return 'hair';
    if (/^Sp_Hi_Tail/i.test(name) || name === 'しっぽ') return 'tail';
    if (/^Sp_Ch_/i.test(name))        return 'cloth';
    if (/^Sp_Ar_/i.test(name))        return 'sleeve';
    if (/^Sp_Hi_MSkirt/i.test(name))  return 'skirt';
    return null;
  }
  // 分组 -> { 物理参数, 大开关键名 }（sleeve 归到 cloth 开关下，与案例一致）
  var KIND_CFG = {
    ear:    { cfg: EAR,    grp: 'ear' },
    hair:   { cfg: HAIR,   grp: 'hair' },
    tail:   { cfg: TAIL,   grp: 'tail' },
    cloth:  { cfg: CLOTH,  grp: 'cloth' },
    sleeve: { cfg: SLEEVE, grp: 'cloth' },
    skirt:  { cfg: SKIRT,  grp: 'skirt' }
  };

  /* 新版 chibi.glb 已带完整贴图（Body/Tail/Hair/Eyes/Face/Cheek/Brows/Mouth），
     材质一律走「贴图优先」，下面这张表只在某个材质既没贴图又没颜色时才兜底。 */
  var PALETTE = {
    'Body':        0xf2e2d2,   // 身体 + 衣服
    'Face':        0xfbe9e0,   // 脸部皮肤
    'Hair':        0xffbcd4,   // 头发 + 帽子 + 兽耳（共用同一材质）
    'Tail':        0xffbcd4,
    'Eyes':        0x4a6dba,
    'Cheek':       0xff9dc0,
    'Eyebrows_L':  0x8a6a52,
    'Eyebrows_R':  0x8a6a52,
    'Mouth':       0xc4676f,
    'Transparent': 0xffffff
  };
  /* 半透明件：优先采用 glb 自带的 alphaMode=BLEND（Cheek / Eyebrows_L / Eyebrows_R 都是），
     这张表只用于「想额外手动调淡」的件名覆盖。 */
  var SOFT_ALPHA = {};

  /* ---------- 动态表情：五官图集的贴图登记 ----------
     三张图集都是 128px 网格（眼睛的「一组」= 左右眼一对 = 2 格宽）：
       Eyes_D  1024x1024 → 4 列(对) x 4 行 = 16 格，实际 15 组
       Mouth_D  512x1024 → 4 列 x 5 行 = 20 格，实际 19 个
       Brows_D 1024x1024 → 4 列 x 3 行（第 3 行只有第 1 格有内容）→ 实际 9 个
     Eyebrows_L / Eyebrows_R 共用同一张图（同一个 image + sampler = 同一个贴图对象），
     所以眉毛天然同步；即使哪天导出成两张，这里也会两张一起改。 */
  var FACE_GROUP = { 'Eyes': 'eyes', 'Mouth': 'mouth', 'Eyebrows_L': 'brows', 'Eyebrows_R': 'brows' };
  var FACE_CELL = {
    eyes:  { u: 0.25, v: 0.125, baseU: 0, baseV: 0 },   // 模型默认格 = 1:1
    mouth: { u: 0.25, v: 0.125, baseU: 0, baseV: 0 },   // 模型默认格 = 1:1（实测 UV，非曼波的 1:2）
    brows: { u: 0.25, v: 0.25,  baseU: 0, baseV: 0 }    // 模型默认格 = 1:1
  };
  var faceTargets = { eyes: [], mouth: [], brows: [] };


  // ----------------------------- 背屏桥状态 -----------------------------
  var aod = false;
  var hintOn = true;
  var gravityOn = true;
  var rafId = null;

  // ----------------------------- DOM -----------------------------
  var canvas    = document.getElementById('c');
  var stage     = document.getElementById('stage');
  var loadingEl = document.getElementById('loading');

  // ----------------------------- 渲染器 / 场景 -----------------------------
  var renderer = new THREE.WebGLRenderer({
    antialias: true, alpha: true, powerPreference: 'high-performance',
    preserveDrawingBuffer: true   // 背屏 WebView 可能随时截屏取帧，保留绘制缓冲更稳
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  // 透明清屏：让 DOM 的 #bg / #clock 透出来（角色身后才是电子时钟）
  renderer.setClearColor(0x000000, 0);
  if (THREE.sRGBEncoding !== undefined) renderer.outputEncoding = THREE.sRGBEncoding;
  canvas.parentNode.insertBefore(renderer.domElement, canvas);
  renderer.domElement.id = 'c';
  canvas.remove();
  var canvasEl = renderer.domElement;
  canvasEl.style.touchAction = 'none'; // 阻止 WebView 把触摸当成滚动/缩放手势

  var scene = new THREE.Scene();
  scene.background = null;   // 透明背景，颜色由 DOM(#bg) 提供

  var camera = new THREE.PerspectiveCamera(FOV, 1, 0.05, 50);
  var focus  = new THREE.Vector3(0, 0.78, 0.05);
  var modelCenter = new THREE.Vector3(0, 0.78, 0.05); // 模型躯干中心世界坐标，时钟靠投影跟随它
  var CAM_PAN_NDC = 0.3;   // 角色在屏幕上的水平位置：NDC x，0=居中 +1=最右。0.3 → 约 65% 屏宽（右侧）

  // ----------------------------- 灯光：环境 + 一盏主光 -----------------------------
  /* 这版 three 不做色彩管理，十六进制色会被当成线性值直接进着色器，
     不转换的话 toon 输出会整体发灰发白。这里统一按 sRGB 解释再转线性，
     于是「亮部」正好等于配色表里写的那个颜色。 */
  function srgb(hex) {
    var c = new THREE.Color(hex);
    if (c.convertSRGBToLinear) c.convertSRGBToLinear();
    return c;
  }

  /* 光照：移除主光（方向光），改用均匀环境光，让动漫模型呈平面、无 3D 阴影的观感。
     输出(线性) = 环境强度 * 材质色，故环境强度取 1 即显示配色本色（无亮暗阶梯）。 */
  var ambient = new THREE.AmbientLight(0xffffff, 1.0);
  scene.add(ambient);

  // ----------------------------- toon 阶梯渐变贴图 -----------------------------
  function makeGradientMap() {
    // 3 段硬边：暗部 / 中间调 / 亮部
    var steps = [0.25, 0.60, 1.0];
    var data = new Uint8Array(steps.length * 4);
    for (var i = 0; i < steps.length; i++) {
      var v = Math.round(steps[i] * 255);
      data[i * 4] = v; data[i * 4 + 1] = v; data[i * 4 + 2] = v; data[i * 4 + 3] = 255;
    }
    var tex = new THREE.DataTexture(data, steps.length, 1, THREE.RGBAFormat);
    tex.minFilter = THREE.NearestFilter;
    tex.magFilter = THREE.NearestFilter;
    tex.generateMipmaps = false;
    tex.needsUpdate = true;
    return tex;
  }
  var gradTex = makeGradientMap();

  // ----------------------------- 描边材质（反向外壳） -----------------------------
  var outlineUniforms = { outlineWidth: { value: OUTLINE_W } };
  var outlineMat = new THREE.MeshBasicMaterial({
    color: 0x000000,
    side: THREE.BackSide,
    fog: false,
    depthWrite: true,
    /* 关键：这一版 three 只有在 material.skinning 为 true 时才会给材质编译
       USE_SKINNING，否则模型会一直按「绑定姿态」渲染 —— 骨骼照常运算、画面却纹丝不动。
       描边外壳也是 SkinnedMesh，同样必须打开。 */
    skinning: true
  });
  /* MeshBasicMaterial 的顶点着色器只在 USE_ENVMAP 下才声明 objectNormal，
     这里手动把 beginnormal / skinnormal 两个 chunk 插进去，
     拿到「已蒙皮的法线」，再沿法线把顶点外扩 —— 即反向外壳描边。 */
  outlineMat.onBeforeCompile = function (shader) {
    shader.uniforms.outlineWidth = outlineUniforms.outlineWidth;
    shader.vertexShader = 'uniform float outlineWidth;\n' + shader.vertexShader
      .replace(
        '#include <skinbase_vertex>',
        '#include <skinbase_vertex>\n\t#include <beginnormal_vertex>\n\t#include <skinnormal_vertex>'
      )
      .replace(
        '#include <skinning_vertex>',
        '#include <skinning_vertex>\n\tfloat _onl = length( objectNormal );\n\tif ( _onl > 1e-6 ) transformed += ( objectNormal / _onl ) * outlineWidth;'
      );
    outlineMat.userData.shader = shader;
  };

  // ----------------------------- 状态容器 -----------------------------
  var model = null;
  var dragBones = [];   // 互动骨骼（拖拽 + 回弹）
  var chains = [];      // 物理骨骼链
  var phyBoneCount = 0; // 物理骨骼总数（性能/自检用）
  var skinned = [];      // 蒙皮网格（描边 / 骨骼相关）
  var frameMeshes = [];  // 参与相机取景的全部网格

  var raycaster = new THREE.Raycaster();
  var activePointers = new Map(); // pointerId -> 拖拽记录
  var plane = new THREE.Plane();
  var ndc = new THREE.Vector2();

  // 复用的临时量（避免每帧 new）
  var tA = new THREE.Vector3(), tB = new THREE.Vector3(), tC = new THREE.Vector3();
  var tD = new THREE.Vector3(), tE = new THREE.Vector3(), tF = new THREE.Vector3();
  var qA = new THREE.Quaternion(), qB = new THREE.Quaternion(), qC = new THREE.Quaternion();
  var vP = new THREE.Vector3(), vQ = new THREE.Quaternion(), vS = new THREE.Vector3();
  var m4 = new THREE.Matrix4();
  var gravity = new THREE.Vector3();
  var cameraDir = new THREE.Vector3();

  function applyDragBone(b) {
    // 目标世界坐标 = 静止世界位置 + 偏移，再换算回父骨骼局部坐标
    tA.copy(b.restWorld).add(b.offset);
    tB.copy(tA).applyMatrix4(b.parentInv);
    b.bone.position.copy(tB);
  }

  // ----------------------------- 加载模型 -----------------------------
  var mixer = null, danceClip = null, danceAction = null, walkClip = null, walkAction = null, runClip = null, runAction = null;
  var dancing = false, wasDancing = false, wasWalking = false, wasRunning = false;   // 音乐/步行/跑步模式动画播放状态
  var baseYaw = 0;                               // 模型初始偏航（加载时记录），非步行模式回到此值
  var WALK_YAW = (-30) * Math.PI / 180;          // 步行模式整体偏航：斜左侧 30°（若朝向相反改成 +30）
  var loader = new THREE.GLTFLoader();
  loader.load('model/chibi.glb',
    function (gltf) {
      model = gltf.scene;
      baseYaw = model.rotation.y;     // 记录模型出厂偏航，步行模式在其基础上叠加 WALK_YAW
      scene.add(model);
      model.updateMatrixWorld(true);

      model.traverse(function (obj) {
        if (obj.isMesh) {
          obj.frustumCulled = false; // 骨骼移动后包围盒失效，关闭剔除
          frameMeshes.push(obj);     // 参与相机取景（不限于蒙皮网格）
          if (obj.isSkinnedMesh) skinned.push(obj);
          toonify(obj);
        }
      });

      // 描边（必须在 toonify 之后建，且几何体共享）
      for (var i = 0; i < skinned.length; i++) addOutline(skinned[i]);

      model.updateMatrixWorld(true);
      estimateTipLengths();   // 先算出末节尾长，互动耳的命中折线也要用
      setupInteractive();
      setupChains();
      fitCamera();

      // 表情 / 姿态系统初始化（函数声明已提升，此处直接调用即可）
      setupPose();
      setupEarTwitch();
      rollFace('normal');     // 起手随机一套常规表情

      // 动画：dancing / walking 循环（分别由主循环按状态播放）
      //   dancing、walking 的关键帧都只覆盖身体骨骼（手臂/腿/颈/胯/IK），耳朵·头发·衣服等是静止轨，
      //   所以物理骨骼可以照常叠加在动画之上，互不干扰。
      if (gltf.animations && gltf.animations.length) {
        mixer = new THREE.AnimationMixer(model);
        for (var ai = 0; ai < gltf.animations.length; ai++) {
          var nm = (gltf.animations[ai].name || '').toLowerCase();
          if (nm === 'dancing') { danceClip = gltf.animations[ai]; }
          else if (nm === 'walking') { walkClip = gltf.animations[ai]; }   // 步行循环
          else if (nm === 'running') { runClip = gltf.animations[ai]; }    // 跑步循环（步频更快）
        }
        // 裁剪 walkClip / runClip 到实际关键帧覆盖范围，去掉尾部静止帧（加速后的 GLB 残留空白尾帧
        // 会让循环结尾看起来像暂停）；裁剪后循环接缝紧贴内容、无停顿。
        [walkClip, runClip].forEach(function (clip) {
          if (!clip) return;
          var _maxT = 0;
          for (var _t = 0; _t < clip.tracks.length; _t++) {
            var _times = clip.tracks[_t].times;
            if (_times.length) _maxT = Math.max(_maxT, _times[_times.length - 1]);
          }
          if (_maxT > 0 && _maxT < clip.duration - 1e-4) clip.duration = _maxT;
        });
        if (!danceClip) danceClip = gltf.animations[0];   // 兜底：取第一个动画
        if (danceClip) {
          danceAction = mixer.clipAction(danceClip);
          danceAction.setLoop(THREE.LoopRepeat, Infinity);
          // 不在此 play()；主循环在进入 / 退出音乐模式时再控制
        }
        if (walkClip) {
          walkAction = mixer.clipAction(walkClip);
          walkAction.setLoop(THREE.LoopRepeat, Infinity);
          // 不在此 play()；主循环在进入 / 退出步行/跑步模式时再控制
        }
        if (runClip) {
          runAction = mixer.clipAction(runClip);
          runAction.setLoop(THREE.LoopRepeat, Infinity);
          // 不在此 play()；主循环在进入 / 退出跑步模式时再控制
        }
      }

      if (fallbackNames.length) {
        console.warn('[东海帝皇] chibi.glb 未携带贴图/材质颜色，以下材质用了兜底配色：' +
          fallbackNames.join(', ') + '（在 app.js 的 PALETTE 里改）');
      }

      loadingEl.classList.add('hidden');
      setTimeout(function () { loadingEl.style.display = 'none'; }, 600);
    },
    function (xhr) {
      if (xhr.total) {
        var p = Math.round((xhr.loaded / xhr.total) * 100);
        loadingEl.textContent = '正在加载模型… ' + p + '%';
      }
    },
    function (err) {
      console.error(err);
      loadingEl.textContent = '模型加载失败，请检查 model/chibi.glb';
    }
  );

  // ----------------------------- 三渲二：toon 材质 -----------------------------
  /* 材质优先级（保住模型自己的美术效果，只在信息缺失时才介入）：
       1) 模型自带贴图 map     → 贴图 × 自带颜色（颜色缺省为白），完全用模型的
       2) 模型自带 baseColor   → 直接用
       3) 两者都没有           → 回退到 PALETTE 兜底配色
     当前 chibi.glb 九个材质都带贴图，走第 1 条；PALETTE 只是保险。
     无论走哪条，都只把「着色模型」换成 toon，不改变模型本身的图案。 */
  var fallbackNames = [];

  function isWhite(c) {
    return c && c.r === 1 && c.g === 1 && c.b === 1;
  }

  function toonify(mesh) {
    var src = mesh.material;
    var name = (src && src.name) ? src.name : '';
    var alpha = SOFT_ALPHA[name];

    var hasMap = !!(src && src.map);
    var hasColor = !!(src && src.color && !isWhite(src.color));

    var m = new THREE.MeshToonMaterial({
      color: 0xffffff,
      gradientMap: gradTex,
      side: THREE.DoubleSide,
      skinning: true      // 见 outlineMat 处的说明：不开这个骨骼不会生效
    });

    if (hasMap) {
      m.map = src.map;
      if (THREE.sRGBEncoding !== undefined) m.map.encoding = THREE.sRGBEncoding;
      if (hasColor) m.color.copy(src.color);            // 贴图 + 自带染色

      // 五官图集：登记贴图并关掉 mipmap（相邻格不会因各级 mip 串色）
      var grp = FACE_GROUP[name];
      if (grp && faceTargets[grp].indexOf(m.map) < 0) {
        m.map.wrapS = THREE.ClampToEdgeWrapping;
        m.map.wrapT = THREE.ClampToEdgeWrapping;
        m.map.minFilter = THREE.LinearFilter;
        m.map.generateMipmaps = false;
        m.map.anisotropy = 1;
        m.map.needsUpdate = true;
        faceTargets[grp].push(m.map);
      }
    } else if (hasColor) {
      m.color.copy(src.color);                          // 仅自带颜色
    } else {
      m.color.copy(srgb((PALETTE[name] !== undefined) ? PALETTE[name] : 0xffffff));
      if (fallbackNames.indexOf(name) < 0) fallbackNames.push(name);
    }

    // 半透明：先按 glb 自带设置（alphaMode=BLEND），再允许按件名手动覆盖
    if (src && src.transparent) {
      m.transparent = true;
      m.opacity = (src.opacity !== undefined) ? src.opacity : 1;
      m.depthWrite = (m.opacity >= 0.99);
    }
    if (alpha !== undefined) {
      m.transparent = true; m.opacity = alpha; m.depthWrite = false;
    }
    m.name = name;
    mesh.material = m;
  }

  // ----------------------------- 三渲二：黑色描边 -----------------------------
  function addOutline(mesh) {
    if (mesh.material && mesh.material.transparent) return; // 半透明件（腮红/眉毛）不描边
    var om = new THREE.SkinnedMesh(mesh.geometry, outlineMat);
    om.bind(mesh.skeleton, mesh.bindMatrix);
    om.frustumCulled = false;
    om.renderOrder = -1;
    if (mesh.parent) mesh.parent.add(om); else scene.add(om);
  }

  // ----------------------------- 骨骼名解析 -----------------------------
  /* GLTFLoader 会用 PropertyBinding.sanitizeNodeName 处理节点名：
     空格→下划线，并删掉 . [ ] : / 这些保留字符。
     所以 glb 里的「耳.L」加载后实际叫「耳L」，这里两种写法都能找到。 */
  function findBone(name) {
    if (!model) return null;
    var b = model.getObjectByName(name);
    if (b) return b;
    var alt = String(name).replace(/\s/g, '_').replace(/[\[\]\.:\/]/g, '');
    b = model.getObjectByName(alt);
    if (b) return b;
    // 大小写不敏感兜底：东海帝皇等模型的骨骼名是小写（head / neck）
    var lower = String(name).toLowerCase();
    var found = null;
    model.traverse(function (o) {
      if (found || !o.isBone) return;
      if (o.name && o.name.toLowerCase() === lower) found = o;
    });
    return found;
  }

  // ----------------------------- 互动骨骼（拖拽手柄） -----------------------------
  function setupInteractive() {
    for (var i = 0; i < INTERACTIVE.length; i++) {
      var bone = findBone(INTERACTIVE[i]);
      // 兜底：找不到就拿 Head 下第一个 El 名字里带 Ear_01 的骨骼的父节点当手柄
      if (!bone && model) {
        model.traverse(function (o) {
          if (bone || !o.isBone) return;
          if (o.name.indexOf('Ear_01') === 0) {
            if (INTERACTIVE[i].indexOf('_L') >= 0 && o.name.indexOf('_L') < 0) return;
            if (INTERACTIVE[i].indexOf('_R') >= 0 && o.name.indexOf('_R') < 0) return;
            bone = (o.parent && o.parent.isBone) ? o.parent : o;
          }
        });
      }
      if (!bone) { console.warn('未找到互动骨骼:', INTERACTIVE[i]); continue; }

      var restWorld = new THREE.Vector3();
      bone.getWorldPosition(restWorld);

      var b = {
        bone: bone,
        restWorld: restWorld,
        parentInv: bone.parent.matrixWorld.clone().invert(),
        offset: new THREE.Vector3(),
        velocity: new THREE.Vector3(),
        dragging: false,
        springing: false,
        pointerId: null,
        grabWorld: null,         // 提示光点 / 双耳互斥用的世界锚点
        pts: [],                 // 耳骨链的世界坐标折线（含末端），用于屏幕命中判定
        anchor: new THREE.Vector3(), // 按下时的世界落点（拖拽原点，避免起手跳变）
        lastT: 0,
        lastOffset: new THREE.Vector3(),
        sprite: null
      };
      dragBones.push(b);
    }

    /* 每只耳骨的屏幕折线：用于命中判定（点到折线的最短距离），
       这样用户点耳朵尖、耳朵中段、耳根都算命中，而不是只有一个圆形判定区。
       从拖拽根骨骼沿子骨骼一路走到末节，再补一个虚拟尾点。 */
    for (var c = 0; c < dragBones.length; c++) {
      var pts = [], acc = new THREE.Vector3(), n = 0;
      var cur = dragBones[c].bone, lastB = null, guard = 0;
      while (cur && guard++ < 8) {
        var w = new THREE.Vector3(); cur.getWorldPosition(w);
        pts.push(w); acc.add(w); n++;
        lastB = cur;
        cur = (cur.children.length && cur.children[0].isBone) ? cur.children[0] : null;
      }
      if (lastB && !cur) {
        var tipW = new THREE.Vector3(0, tipLenOf(lastB, PHY_TIP_L), 0)
          .applyQuaternion(lastB.getWorldQuaternion(qA));
        lastB.getWorldPosition(vP);
        var tw = vP.clone().add(tipW);
        pts.push(tw); acc.add(tw); n++;
      }
      dragBones[c].pts = pts;
      dragBones[c].grabWorld = n ? acc.multiplyScalar(1 / n) : dragBones[c].restWorld.clone();
    }
  }

  // ----------------------------- 物理骨骼链 -----------------------------
  /* 末节骨骼没有子骨骼可以「指路」，用它主要影响的那撮顶点沿骨骼轴的伸展长度当尾长，
     这样长短不一的发片 / 裙摆 / 披风能各自拿到合适的力臂，不用逐根手填。 */
  var tipLenCache = {};

  function estimateTipLengths() {
    for (var mi = 0; mi < skinned.length; mi++) {
      var mesh = skinned[mi];
      var geo = mesh.geometry;
      var pos = geo.attributes.position;
      var sIdx = geo.attributes.skinIndex;
      var sWt = geo.attributes.skinWeight;
      if (!pos || !sIdx || !sWt) continue;
      var bones = mesh.skeleton.bones;
      var best = [], bp = [], bd = [];
      for (var i = 0; i < bones.length; i++) {
        best[i] = 0;
        var wp = new THREE.Vector3(); bones[i].getWorldPosition(wp);
        bp[i] = wp;
        var d = new THREE.Vector3(0, 1, 0);
        if (bones[i].parent) {
          var pp = new THREE.Vector3(); bones[i].parent.getWorldPosition(pp);
          d.copy(wp).sub(pp);
          if (d.lengthSq() < 1e-10) d.set(0, 1, 0);
        }
        bd[i] = d.normalize();
      }
      var wArr = sWt.array, iArr = sIdx.array;
      for (var vi = 0; vi < pos.count; vi++) {
        var x = pos.getX(vi), y = pos.getY(vi), z = pos.getZ(vi);
        for (var k = 0; k < 4; k++) {
          if (wArr[vi * 4 + k] < 0.45) continue;
          var bi = iArr[vi * 4 + k];
          if (bi < 0 || bi >= bones.length) continue;
          var pr = (x - bp[bi].x) * bd[bi].x + (y - bp[bi].y) * bd[bi].y + (z - bp[bi].z) * bd[bi].z;
          if (pr > best[bi]) best[bi] = pr;
        }
      }
      for (var n = 0; n < bones.length; n++) {
        if (best[n] <= 0) continue;
        var nm = bones[n].name;
        tipLenCache[nm] = Math.max(tipLenCache[nm] || 0, best[n]);
      }
    }
  }

  function tipLenOf(bone, fallback) {
    var L = tipLenCache[bone.name];
    if (L === undefined || L < 0.008 || L > 0.6) return fallback;
    return L;
  }

  function setupChains() {
    if (!model) return;
    var allBones = [];
    model.traverse(function (o) { if (o.isBone) allBones.push(o); });

    // 为单根骨骼构建物理状态对象 st（与原来 setupChains 内逻辑一致）
    function makeSt(bone, cfg, nextBone) {
      var tipLocal;
      if (nextBone && nextBone.parent === bone) tipLocal = nextBone.position.clone();
      else tipLocal = new THREE.Vector3(0, tipLenOf(bone, PHY_TIP_L), 0);

      var restQuat = bone.quaternion.clone();
      var restM = new THREE.Matrix4().compose(bone.position.clone(), restQuat, bone.scale.clone());
      var restTipLocal = tipLocal.clone().applyMatrix4(restM);   // 父空间常量

      var st = {
        bone: bone,
        restQuat: restQuat,
        restTipLocal: restTipLocal,
        boneLength: tipLocal.length(),
        tail: new THREE.Vector3(),
        vel: new THREE.Vector3(),
        k: cfg.k,
        c: cfg.c,
        grav: cfg.grav,
        maxRad: cfg.max * Math.PI / 180,
        cosMax: Math.cos(cfg.max * Math.PI / 180),
        drag: null            // 若本骨骼同时是拖拽手柄，物理目标要跟着拖拽位移走
      };
      for (var d = 0; d < dragBones.length; d++) {
        if (dragBones[d].bone === bone) { st.drag = dragBones[d]; break; }
      }
      // 初始化尾端到静止位置
      st.tail.copy(restTipLocal).applyMatrix4(bone.parent.matrixWorld);
      return st;
    }

    var kinds = ['ear', 'hair', 'tail', 'cloth', 'sleeve', 'skirt'];
    for (var ki = 0; ki < kinds.length; ki++) {
      var kind = kinds[ki];
      var kc = KIND_CFG[kind];
      if (!PHY_ENABLE[kc.grp]) continue;

      // 根骨骼：同组且父级不是同组（或没有父级）
      var roots = [];
      for (var bi = 0; bi < allBones.length; bi++) {
        var b = allBones[bi];
        if (kindOf(b.name) !== kind) continue;
        var pk = (b.parent && b.parent.isBone) ? kindOf(b.parent.name) : null;
        if (pk !== kind) roots.push(b);
      }

      for (var ri = 0; ri < roots.length; ri++) {
        // 提取所有「根 -> 叶」分支路径（分叉时每个分叉各自成链）
        var lineages = [];
        (function extract(node, acc) {
          acc = acc.concat([node]);
          var kids = [];
          for (var ci = 0; ci < node.children.length; ci++) {
            var ch = node.children[ci];
            if (ch.isBone && kindOf(ch.name) === kind) kids.push(ch);
          }
          if (kids.length === 0) { lineages.push(acc); return; }
          for (var si = 0; si < kids.length; si++) extract(kids[si], acc);
        })(roots[ri], []);

        for (var li = 0; li < lineages.length; li++) {
          // 分叉时根骨骼已被第一条链占用，其余分支从子骨骼起，避免重复 st / 重复施加力
          var path = (li === 0) ? lineages[li] : lineages[li].slice(1);
          if (!path.length) continue;
          var list = [];
          for (var pi = 0; pi < path.length; pi++) {
            var nxt = (pi + 1 < path.length) ? path[pi + 1] : null;
            list.push(makeSt(path[pi], kc.cfg, nxt));
          }
          if (list.length) { chains.push(list); phyBoneCount += list.length; }
        }
      }
    }
  }

  // ----------------------------- 相机：对准正面「上半身」 -----------------------------
  function fitCamera() {
    var box = new THREE.Box3();
    var tmp = new THREE.Vector3();
    for (var i = 0; i < frameMeshes.length; i++) {
      var g = frameMeshes[i].geometry;
      if (!g.boundingBox) g.computeBoundingBox();
      var bb = g.boundingBox;
      box.expandByPoint(tmp.copy(bb.min).applyMatrix4(frameMeshes[i].matrixWorld));
      box.expandByPoint(tmp.copy(bb.max).applyMatrix4(frameMeshes[i].matrixWorld));
    }
    if (box.isEmpty()) box.setFromCenterAndSize(focus, new THREE.Vector3(0.7, 0.9, 0.7));

    // 只取「上半身」：按身高比例裁掉下面一段，上面再留一点白
    var h0 = box.max.y - box.min.y;
    box.min.y += h0 * FRAME_BTM;
    box.max.y += h0 * FRAME_TOP;
    var halfX = h0 * FRAME_HALF;
    box.min.x = Math.min(box.min.x, -halfX);
    box.max.x = Math.max(box.max.x, halfX);

    box.getCenter(focus);
    modelCenter.copy(focus);   // store model center; clock projects from this

    var size = box.getSize(new THREE.Vector3());
    var fovV = FOV * Math.PI / 180;
    var tan = Math.tan(fovV / 2);
    var aspect = camera.aspect || 1;
    var distV = (size.y * 0.5) / tan;
    var distH = (size.x * 0.5) / (tan * aspect);
    var dist = Math.max(distV, distH) * FIT;

    // 水平平移：把角色放到屏幕右侧（只平移取景，不动景别/大小）。
    // 角色中心的目标 NDC x = CAM_PAN_NDC；换算成世界偏移：相机与 lookAt 一起左移 halfW*NDC。
    var halfW = dist * Math.tan(fovV / 2) * aspect;
    // 让“模型中心”精确落在屏幕 NDC = CAM_PAN_NDC 处（与宽高比无关）：
    // 相机位置与 lookAt 一起平移 (modelCenter.x - halfW*NDC)，则模型 NDC_x 恒为 NDC。
    focus.x = modelCenter.x - halfW * CAM_PAN_NDC;

    camera.position.set(focus.x, focus.y, focus.z + dist);
    camera.lookAt(focus);
    camera.updateProjectionMatrix();

    // 描边宽度随相机距离缩放，保证近远景线宽一致
    outlineUniforms.outlineWidth.value = OUTLINE_W * (dist / 2.0);
  }

  // ----------------------------- 尺寸 -----------------------------
  function resize() {
    var w = stage.clientWidth || window.innerWidth;
    var h = stage.clientHeight || window.innerHeight;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    if (frameMeshes.length) fitCamera();
    if (specCanvas) resizeSpectrum();
  }
  window.addEventListener('resize', resize);
  resize();

  // ----------------------------- 倾斜输入：陀螺仪（多源兜底） -----------------------------
  /* 背屏 WebView 里 deviceorientation 并不是一定会来（固件差异很大），所以同时监听三路：
       ① deviceorientationabsolute   某些固件只发这一种
       ② deviceorientation           主流写法
       ③ devicemotion                直接读 accelerationIncludingGravity，最原始也最通用
     谁先给出有效数据就锁谁，之后不再互相打断（不会再出现两路抢着写重力导致的抖动）。
     三路都没有时退化成「指针/手指位置模拟倾斜」，保证电脑预览和拿不到传感器的固件也有反馈。
     真机上想知道到底走了哪一路：控制台敲 __gyro()。 */
  var DEG = Math.PI / 180;
  var FULL_TILT_DEG = 30;          // 倾斜多少度算满舵
  var FULL = Math.sin(FULL_TILT_DEG * DEG);
  var DEAD = 0.05;
  var tilt = { x: 0, y: 0 }, tiltTarget = { x: 0, y: 0 };
  var keyTilt = { x: 0, y: 0 };
  var keys = {};

  /* ------------------------------------------------------------------
     三个传感器通道各自维护「最近一次有效读数的时间戳 / 读数 / 中立位」，
     每帧只挑「最近还有数据在来」的通道里优先级最高的那个用。
     之前的问题是：一旦某个高优先级通道给了第一条有效数据就永久占用输入，
     哪怕它随后哑火（背屏固件很常见：orientation 融合通道要过一会儿才稳定，
     甚至先丢一包数据再停一两秒），期间其余活着的通道（通常是 devicemotion）
     会被优先级判断直接丢掉 → 表现就是「开头一段时间怎么倾斜都没反应」。
     现在任何通道断流超过 STALL_MS 都会自动让位给还活着的通道，
     并且断流超过 REBASE_MS 后回来时重新取中立位，避免带着错误基准一起回来。
     ------------------------------------------------------------------ */
  var STALL_MS  = 700;             // 超过这么久没新数据 = 该通道哑了
  var REBASE_MS = 2200;            // 哑这么久之后才恢复 → 重新取中立位

  function msNow() {
    return (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
  }

  var gyro = {
    src: 'none',                   // absolute / orientation / motion / pointer / none
    evAbs: 0, evOri: 0, evMot: 0,  // 各通道收到的事件数
    zeroRun: 0,                    // 连续「全零」计数：有些固件只发空壳事件
    raw: [0, 0],                   // 当前使用通道的最近一次原始读数
    perm: '',                      // 授权结果（iOS）
    secure: (typeof window.isSecureContext === 'boolean') ? window.isSecureContext : null,
    hasOri: typeof window.DeviceOrientationEvent !== 'undefined',
    hasMot: typeof window.DeviceMotionEvent !== 'undefined',
    firstAt: 0,                    // 首次拿到有效读数的时间戳（ms）
    switches: 0                    // 通道切换次数（诊断用）
  };
  var SRC_PRIO  = { none: 0, pointer: 1, motion: 2, orientation: 3, absolute: 4 };
  var SRC_ORDER = ['absolute', 'orientation', 'motion'];   // 优先级由高到低

  var chan = {};                   // 每通道状态：{ t, x, y, bx, by, hasBase, raw }
  (function () {
    for (var i = 0; i < SRC_ORDER.length; i++) {
      chan[SRC_ORDER[i]] = { t: 0, x: 0, y: 0, bx: 0, by: 0, hasBase: false, raw: [0, 0] };
    }
  })();

  /* 重新取中立位：下次收到读数时的第一个采样就是新的中立姿态。
     息屏唤醒 / 页面重新可见时都要走一遍，否则会带着上一次的中立位、回来就歪着。 */
  function resetGyro() {
    for (var i = 0; i < SRC_ORDER.length; i++) {
      var c = chan[SRC_ORDER[i]];
      c.t = 0; c.hasBase = false;
    }
    gyro.src = 'none';
    gyro.zeroRun = 0;
    tiltTarget.x = 0; tiltTarget.y = 0;
  }

  function markLive(src, x, y) {
    var c = chan[src], t = msNow();
    if (!gyro.firstAt) gyro.firstAt = t;
    if (!c.hasBase || (t - c.t) > REBASE_MS) { c.bx = x; c.by = y; c.hasBase = true; }
    c.t = t; c.x = x; c.y = y;
  }

  /* 当前「活着」的通道：最近 STALL_MS 内还有有效数据的、优先级最高的那个 */
  function pickSrc() {
    var t = msNow();
    for (var i = 0; i < SRC_ORDER.length; i++) {
      var c = chan[SRC_ORDER[i]];
      if (c.hasBase && c.t && (t - c.t) < STALL_MS) return SRC_ORDER[i];
    }
    return null;
  }

  // UI 旋转角：把设备系向量旋到屏幕系
  function screenAngle() {
    var ang = 0;
    try {
      ang = (screen.orientation && typeof screen.orientation.angle === 'number')
        ? screen.orientation.angle : (window.orientation || 0);
    } catch (err) { ang = window.orientation || 0; }
    return ang || 0;
  }

  /* 把「设备系水平重力分量」落到 tiltTarget。
     力度取屏幕平面内重力投影的模长、方向单独归一化：
     任何握持姿态只要倾到位就是满舵，不会被 cos(β) 吃掉某一轴。
     TILT_FLIP_X / Y：万一真机上左右或上下感觉反了，把对应那个改成 -1 即可。
     真机实测「左倾/右倾」是反的 → X 取 -1。 */
  var TILT_FLIP_X = -1, TILT_FLIP_Y = 1;
  function putDeviceGravity(gx, gy) {
    var o = screenAngle() * DEG, co = Math.cos(o), si = Math.sin(o);
    var sx = (gx * co + gy * si) * TILT_FLIP_X;
    var sy = (-gx * si + gy * co) * TILT_FLIP_Y;
    var m = Math.sqrt(sx * sx + sy * sy);
    var mag = m / FULL;
    if (mag > 1) mag = 1;
    if (mag < DEAD) mag = 0;
    if (m > 1e-4) { tiltTarget.x = (sx / m) * mag; tiltTarget.y = (sy / m) * mag; }
    else { tiltTarget.x = 0; tiltTarget.y = 0; }
  }

  /* 每帧挑一个活着的通道写 tiltTarget；一个都没有就返回 false（交给指针模拟） */
  function updateGyroTilt() {
    var s = pickSrc();
    if (!s) return false;
    if (gyro.src !== s) { gyro.src = s; gyro.switches++; }
    var c = chan[s];
    putDeviceGravity(c.x - c.bx, c.y - c.by);
    gyro.raw = c.raw;
    return true;
  }

  /* 设备系「重力朝下」的单位向量（β=俯仰，γ=横滚）：
       g_dev = R^T · (0,0,-1) = ( sinγ·cosβ , -sinβ , -cosγ·cosβ )
     用完整向量做差（而不是只拿 Δβ/Δγ 当小量），
     这样手机接近「翻面朝下看背屏」（β≈±180）时也不会丢符号、不会越倾越没反应。 */
  function devGravity(b, g) {
    var bR = b * DEG, gR = g * DEG;
    return { x: Math.sin(gR) * Math.cos(bR), y: -Math.sin(bR) };
  }

  function onOrientation(e, absolute) {
    if (absolute) gyro.evAbs++; else gyro.evOri++;
    if (!e || e.beta === null || e.gamma === null) return;
    var b = e.beta || 0, g = e.gamma || 0;
    // 全零：空壳事件，既不能当中立位也不算「活着」，别占着坑
    if (Math.abs(b) < 0.001 && Math.abs(g) < 0.001) { gyro.zeroRun++; return; }
    gyro.zeroRun = 0;
    var src = absolute ? 'absolute' : 'orientation';
    chan[src].raw = [+b.toFixed(1), +g.toFixed(1)];
    var cur = devGravity(b, g);
    markLive(src, cur.x, cur.y);
  }

  function onMotion(e) {
    gyro.evMot++;
    var a = e && (e.accelerationIncludingGravity || e.acceleration);
    if (!a || a.x === null || a.x === undefined) return;
    var ax = a.x || 0, ay = a.y || 0, az = a.z || 0;
    var L = Math.sqrt(ax * ax + ay * ay + az * az);
    if (L < 1e-3) return;
    /* 静止时加速度计读到的就是重力反向：g_dev = -a / |a| */
    var ux = -ax / L, uy = -ay / L;
    chan.motion.raw = [+ux.toFixed(2), +uy.toFixed(2)];
    markLive('motion', ux, uy);
  }

  window.addEventListener('deviceorientation', function (e) { onOrientation(e, false); }, true);
  window.addEventListener('deviceorientationabsolute', function (e) { onOrientation(e, true); }, true);
  window.addEventListener('devicemotion', onMotion, true);

  /* iOS / 部分安卓要在用户手势里显式申请。每次触碰都试一次，成本极低、覆盖率高。 */
  function requestGyro() {
    try {
      if (typeof DeviceOrientationEvent !== 'undefined' &&
          typeof DeviceOrientationEvent.requestPermission === 'function') {
        DeviceOrientationEvent.requestPermission()
          .then(function (r) { gyro.perm = r; })
          .catch(function (err) { gyro.perm = 'err'; });
      }
      if (typeof DeviceMotionEvent !== 'undefined' &&
          typeof DeviceMotionEvent.requestPermission === 'function') {
        DeviceMotionEvent.requestPermission().catch(function () {});
      }
    } catch (e) {}
  }
  window.addEventListener('touchstart', requestGyro, { passive: true });
  window.addEventListener('pointerdown', requestGyro, { passive: true });

  /* 尽早把传感器「叫醒」：不等第一次触摸。
     另外页面重新可见时（部分固件会在息屏期间掐断传感器）顺手重取中立位。 */
  requestGyro();
  window.addEventListener('pageshow', function () { requestGyro(); resetGyro(); });
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden) { requestGyro(); resetGyro(); }
  });
  window.addEventListener('focus', function () { requestGyro(); });

  /* 完全没有传感器数据时（电脑预览 / 固件不给）用指针位置模拟倾斜。
     触屏上也生效，但正在拖耳朵时不接管，免得跟手指打架。 */
  var pointerIdle = 0;
  function pointerTilt(cx, cy) {
    if (pickSrc()) return;                 // 有活着的传感器通道 → 不接管
    var dragging = false;
    for (var i = 0; i < dragBones.length; i++) if (dragBones[i].dragging) dragging = true;
    if (dragging) return;
    gyro.src = 'pointer';
    var r = stage.getBoundingClientRect();
    var nx = (cx - r.left) / Math.max(1, r.width) - 0.5;
    var ny = (cy - r.top) / Math.max(1, r.height) - 0.5;
    tiltTarget.x = Math.max(-1, Math.min(1, nx * 2.6));
    tiltTarget.y = Math.max(-1, Math.min(1, -ny * 2.6));
    pointerIdle = 0;
  }
  window.addEventListener('mousemove', function (e) { pointerTilt(e.clientX, e.clientY); }, { passive: true });
  window.addEventListener('touchmove', function (e) {
    if (!e.touches.length) return;
    pointerTilt(e.touches[0].clientX, e.touches[0].clientY);
  }, { passive: true });

  window.addEventListener('keydown', function (e) { keys[e.key] = true; });
  window.addEventListener('keyup', function (e) { keys[e.key] = false; });

  function updateTilt(dt) {
    if (keys['ArrowLeft'] || keys['a']) keyTilt.x = -1;
    else if (keys['ArrowRight'] || keys['d']) keyTilt.x = 1;
    else keyTilt.x = 0;
    if (keys['ArrowUp'] || keys['w']) keyTilt.y = 1;
    else if (keys['ArrowDown'] || keys['s']) keyTilt.y = -1;
    else keyTilt.y = 0;

    var tx = tiltTarget.x, ty = tiltTarget.y;
    if (keyTilt.x !== 0 || keyTilt.y !== 0) {
      tx = keyTilt.x; ty = keyTilt.y;
    } else if (!updateGyroTilt()) {
      // 一个传感器通道都不活着：走指针模拟，手指抬起 / 鼠标停住后慢慢回正
      if (gyro.src === 'pointer' || gyro.src === 'none') {
        pointerIdle += dt;
        if (pointerIdle > 1.2) {
          var f = Math.exp(-dt * 1.2);
          tiltTarget.x = tx = tx * f;
          tiltTarget.y = ty = ty * f;
        }
      }
    }
    var k = 1 - Math.exp(-dt * 10);
    tilt.x += (tx - tilt.x) * k;
    tilt.y += (ty - tilt.y) * k;
  }

  // ----------------------------- 指针交互（拖拽耳朵） -----------------------------
  function pointerToNDC(e, out) {
    var rect = canvasEl.getBoundingClientRect();
    out.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    out.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
  }

  // 世界坐标 → 屏幕像素
  function project(world, out) {
    vP.copy(world).project(camera);
    var rect = canvasEl.getBoundingClientRect();
    out.x = (vP.x * 0.5 + 0.5) * rect.width;
    out.y = (-vP.y * 0.5 + 0.5) * rect.height;
    return out;
  }
  var spA = new THREE.Vector2(), spB = new THREE.Vector2();
  var chainScreen = [];

  // 点到线段的最短距离
  function distToSeg(px, py, ax, ay, bx, by) {
    var vx = bx - ax, vy = by - ay;
    var wx = px - ax, wy = py - ay;
    var L2 = vx * vx + vy * vy;
    var t = (L2 > 1e-6) ? (wx * vx + wy * vy) / L2 : 0;
    if (t < 0) t = 0; else if (t > 1) t = 1;
    var dx = px - (ax + vx * t), dy = py - (ay + vy * t);
    return Math.sqrt(dx * dx + dy * dy);
  }

  // 点到「耳骨链屏幕折线」的最短距离
  function distToChain(b, px, py) {
    var n = b.pts.length;
    if (n < 2) return 1e9;
    while (chainScreen.length < n) chainScreen.push(new THREE.Vector2());
    for (var i = 0; i < n; i++) project(b.pts[i], chainScreen[i]);
    var best = 1e9;
    for (var i = 0; i < n - 1; i++) {
      var d = distToSeg(px, py, chainScreen[i].x, chainScreen[i].y,
        chainScreen[i + 1].x, chainScreen[i + 1].y);
      if (d < best) best = d;
    }
    return best;
  }

  function pickBone(e) {
    var rect = canvasEl.getBoundingClientRect();
    var px = e.clientX - rect.left, py = e.clientY - rect.top;

    // 命中半径：两耳不能互相抢，按屏幕间距收敛
    var R = GRAB_PX;
    if (dragBones.length === 2 &&
        dragBones[0].grabWorld && dragBones[1].grabWorld) {
      project(dragBones[0].grabWorld, spA);
      project(dragBones[1].grabWorld, spB);
      var d = spA.distanceTo(spB);
      if (d > 1) R = Math.min(R, d * 0.45);
    }

    var best = null, bestD = R;
    for (var i = 0; i < dragBones.length; i++) {
      var b = dragBones[i];
      if (b.dragging) continue;              // 已被另一根手指占用
      var dd = distToChain(b, px, py);
      if (dd < bestD) { bestD = dd; best = b; }
    }
    return best;
  }

  function onDown(e) {
    if (aod || !model) return;
    e.preventDefault();
    var b = pickBone(e);
    if (b) {
      camera.getWorldDirection(cameraDir);
    plane.setFromNormalAndCoplanarPoint(cameraDir, b.restWorld);

    // 按下时的世界落点当拖拽原点：之后只按「位移」拉扯，起手不会把耳朵吸到指尖
    pointerToNDC(e, ndc);
    raycaster.setFromCamera(ndc, camera);
    if (!raycaster.ray.intersectPlane(plane, tA)) return;
    b.anchor.copy(tA);

    b.dragging = true;
    b.springing = false;
    b.pointerId = e.pointerId;
    b.velocity.set(0, 0, 0);
    b.lastT = 0;
    b.lastOffset.copy(b.offset);

    activePointers.set(e.pointerId, { b: b, plane: plane.clone() });
    try { canvasEl.setPointerCapture(e.pointerId); } catch (_) {}

      hintOn = false;                              // 首次上手后隐藏引导文案
      return;
    }
    // 没点到耳朵 → 看是不是点到了 head（摸头踉跄 / 连点生气）
    if (headHit(e)) registerHeadTap();
  }

  function onMove(e) {
    if (aod || !model) return;
    if (!activePointers.has(e.pointerId)) return;
    e.preventDefault();
    var rec = activePointers.get(e.pointerId);
    var b = rec.b;

    pointerToNDC(e, ndc);
    raycaster.setFromCamera(ndc, camera);
    if (!raycaster.ray.intersectPlane(rec.plane, tA)) return;

    var offset = tB.copy(tA).sub(b.anchor);                     // 相对按下落点的位移
    if (offset.length() > MAX_PULL) offset.setLength(MAX_PULL); // 有限距离

    // 估算释放速度，让回弹更自然
    var now = performance.now();
    if (b.lastT) {
      var ddt = (now - b.lastT) / 1000;
      if (ddt > 0) {
        b.velocity.copy(offset).sub(b.lastOffset).multiplyScalar(1 / ddt);
        if (b.velocity.length() > VEL_CLAMP) b.velocity.setLength(VEL_CLAMP);
      }
    }
    b.lastT = now;
    b.lastOffset.copy(offset);
    b.offset.copy(offset);
    applyDragBone(b);
  }

  function onUp(e) {
    if (!activePointers.has(e.pointerId)) return;
    e.preventDefault();
    var b = activePointers.get(e.pointerId).b;
    b.dragging = false;
    b.pointerId = null;
    b.springing = true;      // 松手 → 布丁弹簧回弹
    b.lastT = 0;
    try { canvasEl.releasePointerCapture(e.pointerId); } catch (_) {}
    activePointers.delete(e.pointerId);
  }

  canvasEl.addEventListener('pointerdown', onDown);
  canvasEl.addEventListener('pointermove', onMove);
  canvasEl.addEventListener('pointerup', onUp);
  canvasEl.addEventListener('pointercancel', onUp);
  canvasEl.addEventListener('contextmenu', function (e) { e.preventDefault(); });

  // ----------------------------- 互动骨骼：布丁弹簧回弹 -----------------------------
  function stepDragSpring(b, dt) {
    if (!b.springing) return;
    var steps = 2, h = dt / steps;
    for (var s = 0; s < steps; s++) {
      var pull = b.offset.length();
      var kEff = SPRING_K * (1 + NONLINEAR * (pull / MAX_PULL)); // 拉越远越猛
      tA.copy(b.offset).multiplyScalar(-kEff);
      tB.copy(b.velocity).multiplyScalar(-SPRING_C);
      tA.add(tB);                       // 加速度
      b.velocity.addScaledVector(tA, h);
      b.offset.addScaledVector(b.velocity, h);
    }
    if (b.offset.length() < 0.0008 && b.velocity.length() < 0.01) {
      b.offset.set(0, 0, 0);
      b.velocity.set(0, 0, 0);
      b.springing = false;
    }
    applyDragBone(b);
  }

  // ----------------------------- 物理骨骼链：真实弹簧链 -----------------------------
  /* 每根物理骨骼把「尾端」当成一个质点：
       - 静止尾端由「父骨骼当前世界矩阵 × 静止局部变换」算出（父动了 → 目标跟着动）
       - 弹簧把质点拉向目标位置，重力（陀螺仪）叠加进去
       - 解完再用长度约束把尾端拉回骨长，最后反算骨骼旋转
     父级运动（拖拽根骨骼 / 上一段的回弹）会自然以惯性逐级往链尾传递。 */
  function stepChain(list, dt) {
    for (var i = 0; i < list.length; i++) {
      var st = list[i];
      var bone = st.bone;
      var pw = bone.parent.matrixWorld;

      // 骨骼原点（世界）
      var worldPos = tA.copy(bone.position).applyMatrix4(pw);
      // 静止尾端（世界）
      // 链首骨骼若被拖拽，它的静止目标要跟着位移一起走，否则物理会把耳朵往回拽、跟手指打架
      var restTail = tB.copy(st.restTipLocal).applyMatrix4(pw);
      if (st.drag) restTail.add(st.drag.offset);
      /* 额外摆动（耳朵偶尔抖两下）：把静止尾端绕骨骼原点转一下。
         物理会带着惯性追过去、再弹回来，于是抖完有自然余振。 */
      if (st.extraQ) {
        tB.sub(worldPos).applyQuaternion(st.extraQ).add(worldPos);
        restTail.copy(tB);
      }

      // a = -K·x - C·v + g·grav
      tC.copy(st.tail).sub(restTail).multiplyScalar(-st.k);
      tD.copy(st.vel).multiplyScalar(-st.c);
      tD.addScaledVector(gravity, st.grav);
      tC.add(tD);
      st.vel.addScaledVector(tC, dt);
      st.tail.addScaledVector(st.vel, dt);

      // 长度约束：尾端必须落在以骨骼原点为球心、骨长为半径的球面上
      tE.copy(st.tail).sub(worldPos);
      if (tE.lengthSq() < 1e-12) tE.copy(restTail).sub(worldPos);
      tE.setLength(st.boneLength);

      // 当前方向（单位向量）
      tC.copy(tE).normalize();
      // 静止方向（单位向量）
      tF.copy(restTail).sub(worldPos).normalize();

      // 偏角限制：超出就把方向拉回锥面上，并吃掉向外的径向速度，避免顶着边界抖
      var cAng = tF.dot(tC);
      if (cAng < st.cosMax) {
        tD.crossVectors(tF, tC);
        if (tD.lengthSq() > 1e-12) {
          tD.normalize();
          var ang = Math.acos(cAng < -1 ? -1 : (cAng > 1 ? 1 : cAng));
          var excess = ang - st.maxRad;
          if (excess > 0) {
            qC.setFromAxisAngle(tD, -excess);
            tC.applyQuaternion(qC).normalize();
            var vr = st.vel.dot(tC);
            if (vr > 0) st.vel.addScaledVector(tC, -vr);   // 去掉沿骨轴向外的分量
          }
        }
      }

      st.tail.copy(worldPos).addScaledVector(tC, st.boneLength);

      // 由尾端方向反算骨骼旋转
      qA.setFromUnitVectors(tF, tC);                   // 世界空间的增量旋转

      pw.decompose(vP, vQ, vS);                        // 父骨骼世界旋转
      qB.copy(vQ).invert().multiply(qA).multiply(vQ);  // 转到父空间
      bone.quaternion.copy(qB.multiply(st.restQuat));

      // 立刻刷新，让链上下一段读到最新的父矩阵
      bone.updateMatrixWorld(true);
    }
  }

  // ============================ 动态表情：五官 UV 切换 ============================
  /* 用户给的组合范围是「行:列」，这里统一换成 0 基下标（每行 4 列）：
       RC(2, [1, 4]) → 第二行第 1 列 / 第 4 列。眼睛的「列」= 一对眼睛。 */
  function RC(row, cols) {
    var out = [];
    for (var i = 0; i < cols.length; i++) out.push((row - 1) * 4 + (cols[i] - 1));
    return out;
  }

  var FACE_SET = {
    /* 常规：眉毛 1:1-2 2:1 ｜ 眼睛 1:1-3 3:2-3 ｜ 嘴巴 1:1-3 2:3 3:2 4:2+4 5:1-2 */
    normal: {
      brows: RC(1, [1, 2]).concat(RC(2, [1])),
      eyes:  RC(1, [1, 2, 3]).concat(RC(3, [2, 3])),
      mouth: RC(1, [1, 2, 3]).concat(RC(2, [3]), RC(3, [2]), RC(4, [2, 4]), RC(5, [1, 2]))
    },
    /* 眩晕疲惫：眉毛 1:1-2 2:1 ｜ 眼睛 2:4 3:1+3 4:1+3 ｜ 嘴巴 1:4 2:1 4:2-3 5:3 */
    dizzy: {
      brows: RC(1, [1, 2]).concat(RC(2, [1])),
      eyes:  RC(2, [4]).concat(RC(3, [1, 3]), RC(4, [1, 3])),
      mouth: RC(1, [4]).concat(RC(2, [1]), RC(4, [2, 3]), RC(5, [3]))
    },
    /* 兴奋（充电/步行/跑步）：眉毛 1:1-2 2:1 ｜ 眼睛 1:1-3 3:2-3 ｜ 嘴巴 1:2-3 3:2 4:4 5:1-2 */
    excited: {
      brows: RC(1, [1, 2]).concat(RC(2, [1])),
      eyes:  RC(1, [1, 2, 3]).concat(RC(3, [2, 3])),
      mouth: RC(1, [2, 3]).concat(RC(3, [2]), RC(4, [4]), RC(5, [1, 2]))
    },
    /* 音乐模式：眉毛 1:1-2 2:1 ｜ 眼睛 2:4 3:1-3 ｜ 嘴巴 1:2-3 3:2 4:4 5:1-2 */
    music: {
      brows: RC(1, [1, 2]).concat(RC(2, [1])),
      eyes:  RC(2, [4]).concat(RC(3, [1, 2, 3])),
      mouth: RC(1, [2, 3]).concat(RC(3, [2]), RC(4, [4]), RC(5, [1, 2]))
    }
  };

  var EYE_BLINK     = RC(3, [1, 2]);                                        // 眨眼帧 3:1 / 3:2
  var EYE_NO_BLINK  = RC(2, [4]).concat(RC(3, [1, 2, 3, 4]), RC(4, [3]));   // 抽到这些就不眨眼
  var EYE_BLINK_BAN = RC(3, [2])[0];                                        // 生气/眩晕时不能用它眨眼

  var face = {
    group: 'normal',
    hold: 0,            // 当前这组表情还要保持多久（秒）
    brows: -1, eyes: -1, mouth: -1,
    blinkT: 2.0,        // 距下次眨眼的倒计时
    blinkLeft: 0        // 眨眼动作剩余时间（>0 时显示闭眼帧）
  };

  /* 把某一格贴到部件上：只改 offset（repeat 恒为 1，因为网格 UV 本身已经落在单格里） */
  function setFaceCell(group, idx) {
    var c = FACE_CELL[group], maps = faceTargets[group];
    if (idx < 0 || !maps || !maps.length) return;
    var col = idx % 4, row = (idx / 4) | 0;
    var ox = (col - c.baseU) * c.u, oy = (row - c.baseV) * c.v;
    for (var i = 0; i < maps.length; i++) maps[i].offset.set(ox, oy);
  }

  function pickRand(arr, cur) {
    if (!arr || !arr.length) return -1;
    if (arr.length === 1) return arr[0];
    var v = cur, guard = 0;
    while (v === cur && guard++ < 12) v = arr[(Math.random() * arr.length) | 0];
    return v;
  }

  function rollFace(group) {
    var s = FACE_SET[group] || FACE_SET.normal;
    face.group = group;
    face.brows = pickRand(s.brows, face.brows);
    face.eyes  = pickRand(s.eyes,  face.eyes);
    face.mouth = pickRand(s.mouth, face.mouth);
    setFaceCell('brows', face.brows);
    setFaceCell('eyes',  face.eyes);
    setFaceCell('mouth', face.mouth);
    face.hold = 4.5 + Math.random() * 6.5;      // 隔几秒换一套搭配
    face.blinkT = Math.min(face.blinkT, 1.2 + Math.random() * 3.0);
  }

  function updateFace(dt) {
    if (!model || !faceTargets.eyes.length) return;

    var want = exprState();
    face.hold -= dt;
    if (want !== face.group || face.hold <= 0) rollFace(want);

    if (face.blinkLeft > 0) {                    // 眨眼动作播完 → 回到当前眼神
      face.blinkLeft -= dt;
      if (face.blinkLeft <= 0) { face.blinkLeft = 0; setFaceCell('eyes', face.eyes); }
      return;
    }

    face.blinkT -= dt;
    if (face.blinkT > 0) return;
    face.blinkT = 1.6 + Math.random() * 3.4;
    if (EYE_NO_BLINK.indexOf(face.eyes) >= 0) return;   // 这几种眼神本身就是闭眼/特殊态

    var pool = [EYE_BLINK[0], EYE_BLINK[1]];
    if (face.group === 'dizzy') {
      pool = [EYE_BLINK[0]];                            // 眩晕时 3:2 不当眨眼帧
    }
    setFaceCell('eyes', pool[(Math.random() * pool.length) | 0]);
    face.blinkLeft = 0.10 + Math.random() * 0.06;
  }

  // ============================ 环境信号：电量 / 充电 / 音乐 ============================
  var sig = { level: -1, plugged: 0, music: 0, walk: 0, run: 0 };   // level<0 = 还没收到过；walk=移动(走/跑)，run=跑步(步频更快)
  // 步频阈值：两步间隔 <= 此值视为跑步（快），否则视为步行（慢）。用于区分走路/跑步模式（可按真机手感微调）。
  var RUN_STEP_MAX_MS = 420;
  var WALK_TIMEOUT_MS = 2000;   // 步行态：距上次脚步超过此毫秒数才退出（网页本地计时，保留短暂驻留）
  var RUN_TIMEOUT_MS  = 800;    // 跑步态：距上次脚步超过此毫秒数即退出（步频快，停步应更快回落）
  var lastStepMs = -1e9;        // 最近一次收到 __walk(1)（脚步）的时间戳
  var exprOverride = null, exprOverrideUntil = 0;

  function isCharging() {
    return sig.plugged === 1 || sig.plugged === 2 || sig.plugged === 4;
  }

  function exprState() {
    if (exprOverride && msNow() < exprOverrideUntil) return exprOverride;
    if (sig.run) return 'excited';             // 跑步模式：兴奋组合（最高优先）
    if (sig.walk) return 'excited';            // 步行模式：兴奋组合（优先于音乐）
    if (sig.music) return 'music';
    if (isCharging()) return 'excited';
    if (sig.level >= 0 && sig.level <= 20) return 'dizzy';
    return 'normal';
  }

  window.__sig = function (level, plugged, music) {
    var lv = Number(level), pl = Number(plugged), mu = Number(music);
    if (isFinite(lv) && lv >= 0 && lv <= 100) sig.level = lv;
    if (isFinite(pl) && pl >= 0) sig.plugged = pl;
    if (isFinite(mu)) sig.music = (mu || mu === '1') ? 1 : 0;
  };
  window.__walk = function (on) {
    if (!on) { sig.walk = 0; sig.run = 0; return; }   // 备用 __walk(0)：直接清掉移动态
    var now = msNow();
    // 用与上一步的间隔判断步频：间隔短 → 跑步，间隔长 → 步行
    var interval = (lastStepMs > 0) ? (now - lastStepMs) : 1e9;
    lastStepMs = now;
    sig.walk = 1;
    sig.run = (interval <= RUN_STEP_MAX_MS) ? 1 : 0;
  };
  if (window.__sigQueue) window.__sig(window.__sigQueue[0], window.__sigQueue[1], window.__sigQueue[2]);
  if (window.__walkQueue) window.__walk(window.__walkQueue);

  // ---- 颜色：背景 / 时钟文字 / 时钟背景（由页面内「齿轮菜单」本地设置，不再依赖 var_config） ----
  function isColorStr(v) {
    return typeof v === 'string' && v[0] === '#' && (v.length === 4 || v.length === 7);
  }
  // 3 位短写(#abc) → 6 位(#aabbcc)，<input type=color> 只认 6 位
  function toHex6(v) {
    if (typeof v !== 'string' || v[0] !== '#') return '#000000';
    if (v.length === 4) return '#' + v[1] + v[1] + v[2] + v[2] + v[3] + v[3];
    return v.slice(0, 7);
  }
  var colorState = { bg: '#000000', text: '#ffffff', bgc: '#000000', spec: '#ff5ea8' };
  var bgInput = null, textInput = null, bgcInput = null, cSpecInput = null;

  // 大时钟模式是否套用用户设置的颜色（否则固定「白字 + 半透明黑底」）
  var syncAodColors = false;
  try { syncAodColors = localStorage.getItem('manbo_sync_aod') === '1'; } catch (e) {}
  var soundOn = false;   // 触摸音效开关（设置面板里可开；默认关闭）
  try { soundOn = localStorage.getItem('manbo_sound') === '1'; } catch (e) {}

  // #clockFront：大时钟模式下置顶到模型前方的前景文字层（背景矩形留背后）
  var clockFrontEl = document.getElementById('clockFront');

  function applyColors() {
    var r = document.documentElement.style;
    r.setProperty('--bg', colorState.bg);
    r.setProperty('--clock-bg', colorState.bgc);
    // 文字色：大时钟(AOD)模式下由前景层单独控制，这里仍保留普通模式的色
    r.setProperty('--clock-text', colorState.text);
    if (bgInput)   bgInput.style.background   = toHex6(colorState.bg);
    if (textInput) textInput.style.background = toHex6(colorState.text);
    if (bgcInput)  bgcInput.style.background  = toHex6(colorState.bgc);
    if (cSpecInput) cSpecInput.style.background = toHex6(colorState.spec);
    applyAodClock();   // 大时钟模式时同步前景层样式
  }

  // 大时钟模式前景层：开关关 → 白字 + 半透明黑底；开关开 → 同步色（半透明时钟背景 + 时钟文字）
  function rgbaHex(hex, a) {
    var h = toHex6(hex);
    var r = parseInt(h.slice(1, 3), 16), g = parseInt(h.slice(3, 5), 16), b = parseInt(h.slice(5, 7), 16);
    return 'rgba(' + r + ',' + g + ',' + b + ',' + a + ')';
  }
  function applyAodClock() {
    if (!clockFrontEl) return;
    if (!aod) { clockFrontEl.style.display = 'none'; return; }
    clockFrontEl.style.display = 'inline-block';
    if (syncAodColors) {
      clockFrontEl.style.background = rgbaHex(colorState.bgc, 0.5);
      clockFrontEl.style.color = colorState.text;
    } else {
      clockFrontEl.style.background = 'rgba(0,0,0,.5)';
      clockFrontEl.style.color = '#ffffff';
    }
  }
  // 桥：MAML 仍可能回调（保留兼容），直接写入状态
  window.__setColors = function (bg, ct, cb) {
    if (isColorStr(bg)) colorState.bg = bg;
    if (isColorStr(ct)) colorState.text = ct;
    if (isColorStr(cb)) colorState.bgc = cb;
    applyColors();
    saveColors();
  };

  // ---- 齿轮菜单：本地颜色设置（替代 var_config 的 CustomColor） ----
  function saveColors() {
    try { localStorage.setItem('manbo_colors', JSON.stringify(colorState)); } catch (e) {}
  }
  function loadColors() {
    try {
      var s = localStorage.getItem('manbo_colors');
      if (s) {
        var o = JSON.parse(s);
        if (o && typeof o.bg === 'string') {
          colorState.bg = o.bg;
          colorState.text = o.text || '#ffffff';
          colorState.bgc = o.bgc || '#000000';
          colorState.spec = o.spec || '#ff5ea8';
        }
      }
    } catch (e) {}
  }
  // ---- HSV <-> HEX 转换（自定义取色器用，替代 input[type=color]） ----
  function rgb2hsv(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    var mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn, h = 0;
    if (d > 0) {
      if (mx === r) h = ((g - b) / d) % 6;
      else if (mx === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h *= 60; if (h < 0) h += 360;
    }
    return { h: h, s: mx === 0 ? 0 : d / mx, v: mx };
  }
  function hsv2rgb(h, s, v) {
    var c = v * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = v - c, r, g, b;
    if (h < 60)       { r = c; g = x; b = 0; }
    else if (h < 120) { r = x; g = c; b = 0; }
    else if (h < 180) { r = 0; g = c; b = x; }
    else if (h < 240) { r = 0; g = x; b = c; }
    else if (h < 300) { r = x; g = 0; b = c; }
    else              { r = c; g = 0; b = x; }
    return {
      r: Math.round((r + m) * 255),
      g: Math.round((g + m) * 255),
      b: Math.round((b + m) * 255)
    };
  }
  function hsv2hex(h, s, v) {
    var c = hsv2rgb(h, s, v);
    return '#' + [c.r, c.g, c.b].map(function (n) { return ('0' + n.toString(16)).slice(-2); }).join('');
  }
  function hex2hsv(hex) {
    hex = toHex6(hex);
    return rgb2hsv(
      parseInt(hex.slice(1, 3), 16),
      parseInt(hex.slice(3, 5), 16),
      parseInt(hex.slice(5, 7), 16)
    );
  }

  function setupGearUI() {
    var gearEl = document.getElementById('gear');
    var panelEl = document.getElementById('panel');
    bgInput   = document.getElementById('cBg');
    textInput = document.getElementById('cText');
    bgcInput  = document.getElementById('cBg2');
    cSpecInput = document.getElementById('cSpec');
    var pickerEl = document.getElementById('picker');
    var svEl     = document.getElementById('sv');
    var svDot    = document.getElementById('svDot');
    var hueEl    = document.getElementById('hue');
    var titleEl  = document.getElementById('pickTitle');
    var hexEl    = document.getElementById('pickHex');
    var presetsEl = document.getElementById('presets');
    var idleSw    = document.getElementById('idleSw');
    var syncSw    = document.getElementById('syncSw');
    var soundSw   = document.getElementById('soundSw');
    if (gearEl && panelEl) {
      gearEl.addEventListener('click', function (e) {
        e.stopPropagation();
        panelEl.classList.toggle('open');
      });
      // 点击齿轮 / 面板以外的区域 → 收起菜单
      document.addEventListener('pointerdown', function (e) {
        if (!panelEl.classList.contains('open')) return;
        if (gearEl.contains(e.target) || panelEl.contains(e.target)) return;
        panelEl.classList.remove('open');
      }, true);
    }

    // ---- 自定义 H/S/V 取色器 ----
    // Android WebView 的原生取色只有一排预设色块，因此自己画：
    // SV 明度/饱和度方块 + 色相滑条 + 快捷色，手机 / 电脑表现一致。
    var cur = { h: 0, s: 1, v: 1 };   // 当前编辑的 HSV
    var target = null;                 // 正在编辑的 colorState 键

    function refreshPicker() {
      if (svEl) svEl.style.background =
        'linear-gradient(to top, #000, rgba(0,0,0,0)),' +
        'linear-gradient(to right, #fff, rgba(255,255,255,0)),' +
        'hsl(' + cur.h + ',100%,50%)';
      if (hueEl) hueEl.value = Math.round(cur.h);
      if (svDot) {
        svDot.style.left = (cur.s * 100) + '%';
        svDot.style.top = ((1 - cur.v) * 100) + '%';
      }
      var hex = hsv2hex(cur.h, cur.s, cur.v);
      if (hexEl) hexEl.textContent = hex;
      if (target) { colorState[target] = hex; applyColors(); saveColors(); }
    }
    function markSwatch(key) {
      [[bgInput, 'bg'], [textInput, 'text'], [bgcInput, 'bgc'], [cSpecInput, 'spec']].forEach(function (p) {
        if (p[0]) p[0].classList.toggle('on', p[1] === key);
      });
    }
    function closePicker() {
      if (pickerEl) pickerEl.classList.remove('open');
      target = null;
      markSwatch(null);
    }
    function openPicker(key, label) {
      if (!pickerEl) return;
      target = key;
      cur = hex2hsv(colorState[key]);
      if (titleEl) titleEl.textContent = label;
      pickerEl.classList.add('open');
      markSwatch(key);
      refreshPicker();
    }
    function bindSwatch(el, key, label) {
      if (!el) return;
      el.addEventListener('click', function (e) {
        e.stopPropagation();
        if (pickerEl && pickerEl.classList.contains('open') && target === key) { closePicker(); return; }
        openPicker(key, label);
      });
    }
    bindSwatch(bgInput, 'bg', '背景颜色');
    bindSwatch(textInput, 'text', '时钟文字色');
    bindSwatch(bgcInput, 'bgc', '时钟背景色');
    bindSwatch(cSpecInput, 'spec', '频谱颜色');

    // SV 方块：按住拖动取色（pointer capture，触屏 / 鼠标通用）
    if (svEl) {
      var svFromEvent = function (e) {
        var r = svEl.getBoundingClientRect();
        cur.s = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width));
        cur.v = 1 - Math.min(1, Math.max(0, (e.clientY - r.top) / r.height));
        refreshPicker();
      };
      svEl.addEventListener('pointerdown', function (e) {
        e.stopPropagation(); e.preventDefault();
        if (svEl.setPointerCapture) svEl.setPointerCapture(e.pointerId);
        svFromEvent(e);
        var mv = function (ev) { svFromEvent(ev); };
        var up = function () {
          svEl.removeEventListener('pointermove', mv);
          svEl.removeEventListener('pointerup', up);
          svEl.removeEventListener('pointercancel', up);
        };
        svEl.addEventListener('pointermove', mv);
        svEl.addEventListener('pointerup', up);
        svEl.addEventListener('pointercancel', up);
      });
    }
    if (hueEl) hueEl.addEventListener('input', function () {
      cur.h = Number(hueEl.value);
      refreshPicker();
    });

    // 快捷色：一击直达（手机上比拖方块更快）
    if (presetsEl) {
      var PRESETS = ['#000000', '#ffffff', '#ff4d4d', '#ff9ec7', '#ffd700', '#00e5ff', '#94e203', '#7c4dff'];
      PRESETS.forEach(function (hex) {
        var b = document.createElement('button');
        b.style.background = hex;
        b.addEventListener('click', function (e) {
          e.stopPropagation();
          if (!target) return;
          colorState[target] = hex;
          cur = hex2hsv(hex);
          refreshPicker();
        });
        presetsEl.appendChild(b);
      });
    }

    // 10 秒无操作进入大时钟：开关（记忆到 localStorage）
    if (idleSw) {
      idleSw.checked = idleAodEnabled;
      idleSw.addEventListener('change', function () {
        idleAodEnabled = idleSw.checked;
        try { localStorage.setItem('manbo_idle_aod', idleAodEnabled ? '1' : '0'); } catch (e) {}
        if (!idleAodEnabled) { clearTimeout(idleTimer); if (aod) setAod(false); }
        else bumpUserActive();
      });
    }

    // 大时钟模式：是否套用用户设置的颜色（开关状态记忆到 localStorage）
    if (syncSw) {
      syncSw.checked = syncAodColors;
      syncSw.addEventListener('change', function () {
        syncAodColors = syncSw.checked;
        try { localStorage.setItem('manbo_sync_aod', syncAodColors ? '1' : '0'); } catch (e) {}
        applyAodClock();   // 大时钟模式下即时切换「白字黑底」↔「同步色」
      });
    }
    // 触摸音效：开关（记忆到 localStorage，默认关闭）
    if (soundSw) {
      soundSw.checked = soundOn;
      soundSw.addEventListener('change', function () {
        soundOn = soundSw.checked;
        try { localStorage.setItem('manbo_sound', soundOn ? '1' : '0'); } catch (e) {}
      });
    }
  }
  // ---------------- 大时钟(AOD)模式：统一入口 ----------------
  /* 真机背屏框架不会回调 __setAod，网页无法感知系统 AOD，
     改为「10 秒无点击输入自动进入大时钟模式」；触碰屏幕任意处立即退出。
     window.__setAod 桥保留：若框架某天真回调了也照样生效。 */
  function setAod(v) {
    aod = !!v;
    if (aod) {
      document.body.classList.add('aod');          // 时钟置顶 / 背景压暗 / 隐藏齿轮（挂 body，齿轮/面板已移出舞台）
      var p = document.getElementById('panel');   // 顺手收起可能开着的菜单和取色器
      if (p) p.classList.remove('open');
      var pk = document.getElementById('picker');
      if (pk) pk.classList.remove('open');
    } else {
      document.body.classList.remove('aod');
    }
    applyColors();          // 依据 aod 决定文字色（大时钟模式强制白字，否则用户色）
    resetGyro();            // 模式切换时刷新各通道中立位
    startLoop();            // 兜底：保证一定在跑
  }
  var idleAodEnabled = true;   // 10 秒无操作自动进入大时钟（设置面板里可关）
  try { idleAodEnabled = localStorage.getItem('manbo_idle_aod') !== '0'; } catch (e) {}
  var idleTimer = null;
  function bumpUserActive() {
    if (aod) setAod(false);    // 任何触碰都退出大时钟模式
    clearTimeout(idleTimer);
    if (idleAodEnabled) idleTimer = setTimeout(function () { setAod(true); }, 10000);
  }
  document.addEventListener('pointerdown', bumpUserActive, true);
  window.__setAod = function (v) {
    setAod(v);
    if (!v) bumpUserActive();  // 框架唤醒时同样重置计时
  };

  // 初始化颜色：先读本地存储，再接好齿轮 UI，最后同步到 CSS / 控件
  loadColors();
  setupGearUI();
  applyColors();
  if (window.__colorsQueue) window.__setColors.apply(null, window.__colorsQueue);

  // ---- 角色身后的电子时钟：实时系统时间 HH:MM ----
  var clockEl = document.getElementById('clock');
  var clockLast = '';
  function updateClock() {
    if (!clockEl) return;
    var d = new Date();
    var hh = ('0' + d.getHours()).slice(-2);
    var mm = ('0' + d.getMinutes()).slice(-2);
    var s = hh + ':' + mm;
    if (s !== clockLast) {
      clockLast = s;
      clockEl.textContent = s;
      if (clockFrontEl) clockFrontEl.textContent = s;   // 大时钟模式前景层同步
    }
  }

  // clock follows model center: project to screen px, resolution-independent
  var _proj = new THREE.Vector3();
  function updateClockScreenPos() {
    if (!clockEl) return;
    _proj.copy(modelCenter).project(camera);
    var x = (_proj.x * 0.5 + 0.5) * stage.clientWidth;
    var y = (-_proj.y * 0.5 + 0.5) * stage.clientHeight;
    var px = x + 'px', py = y + 'px';
    clockEl.style.left = px; clockEl.style.top = py;
    if (clockFrontEl) { clockFrontEl.style.left = px; clockFrontEl.style.top = py; }
  }

  // ============================ 摸头触摸音效（随机播放，可叠加不打断） ============================
  var _sndFiles = ['touch1.mp3', 'touch2.mp3', 'touch3.mp3', 'touch4.mp3', 'touch5.mp3'];
  var _sndWarm = [];
  (function () {
    for (var i = 0; i < _sndFiles.length; i++) {
      var a = new Audio('sounds/' + _sndFiles[i]);
      a.preload = 'auto';
      _sndWarm.push(a);
    }
  })();
  // 每次点击都用全新的 Audio 实例播放，多个音效可同时叠加、互不打断
  function playTouchSound() {
    if (!soundOn || !_sndFiles.length) return;
    var n = _sndFiles[(Math.random() * _sndFiles.length) | 0];
    var a = new Audio('sounds/' + n);
    a.volume = 1;
    var pr = a.play();
    if (pr && pr.catch) pr.catch(function () {});   // 忽略自动播放策略导致的拒绝
  }

  // ============================ emotion symbols on head tap ============================
  var symLayer   = document.getElementById('symbols');
  var symEls     = [];
  var symLastTap = -1e9;
  var SYM_CHARS  = ['❤', '🙂', '😋', '😎', '😄', '🥰'];
  var SYM_LIFE   = 1500;
  var SYM_MAX    = 5;
  var _headBone  = null;
  var _hproj     = new THREE.Vector3();
  function getHeadBone() {
    if (!_headBone) _headBone = findBone('Head');
    return _headBone;
  }
  function positionSymbol(rec) {
    var hb = getHeadBone();
    if (!hb) return;
    hb.getWorldPosition(_hproj);
    _hproj.project(camera);
    var x = (_hproj.x * 0.5 + 0.5) * stage.clientWidth;
    var y = (-_hproj.y * 0.5 + 0.5) * stage.clientHeight;
    // 随机偏移在生成时算好（rec.ox/rec.oy），每帧只跟随头部投影、不再抖动：
    // 限定在头部「左侧或右侧」的矩形范围内，上下左右都随机，不是 6 个固定点位
    rec.el.style.left = (x + (rec.ox || 0)) + 'px';
    rec.el.style.top  = (y + (rec.oy || 0)) + 'px';
  }
  function spawnSymbol() {
    if (!symLayer || !model) return;
    var now = msNow();
    var ch = SYM_CHARS[(Math.random() * SYM_CHARS.length) | 0];   // 随机 emoji（❤🙂😋😎😄🥰…）
    symLastTap = now;
    var side = (Math.random() < 0.5) ? -1 : 1;
    // 在头部左侧或右侧的限定范围内随机：横向 6%~20% 屏宽，纵向 -15%~15% 屏高
    // 因此符号会出现在左上/左下/右上/右下这片区域里随机一处，而不是固定 6 点位
    var hx = stage.clientWidth  * (0.06 + Math.random() * 0.14) * side;
    var vy = stage.clientHeight * 0.15;
    var oy = (Math.random() * 2 - 1) * vy;
    var el = document.createElement('div');
    el.className = 'sym';
    el.textContent = ch;
    symLayer.appendChild(el);
    var rec = { el: el, side: side, ox: hx, oy: oy };
    symEls.push(rec);
    if (symEls.length > SYM_MAX) {
      var old = symEls.shift();
      if (old.el && old.el.parentNode) old.el.parentNode.removeChild(old.el);
    }
    positionSymbol(rec);
    setTimeout(function () {
      if (el.parentNode) el.parentNode.removeChild(el);
      var i = symEls.indexOf(rec);
      if (i >= 0) symEls.splice(i, 1);
    }, SYM_LIFE + 60);
  }
  function updateSymbols() {
    for (var i = 0; i < symEls.length; i++) positionSymbol(symEls[i]);
  }

  // ============================ 音乐模式频谱可视化 ============================
  /* 块状堆叠柱形：从底部起伏，仅音乐模式(sig.music)激活；颜色可在设置面板自定义。
     背屏 web 无法访问系统音频，故用「多正弦叠加 + 随机鼓点包络」模拟频谱律动，
     视觉上呈现可信的音乐反应条；进入/退出音乐模式时整体渐显/渐隐。 */
  var specCanvas = document.getElementById('spectrum');
  var specCtx = specCanvas ? specCanvas.getContext('2d') : null;
  var SPEC_BARS = 28;
  var specLevel = [], specTarget = [];
  for (var _si = 0; _si < SPEC_BARS; _si++) { specLevel.push(0); specTarget.push(0); }
  var specAlpha = 0, specBeat = 0, specPhase = 0, specDPR = 1;

  function resizeSpectrum() {
    if (!specCanvas) return;
    specDPR = Math.min(window.devicePixelRatio || 1, 2);
    var w = stage.clientWidth || window.innerWidth;
    var h = stage.clientHeight || window.innerHeight;
    specCanvas.width  = Math.max(1, Math.round(w * specDPR));
    specCanvas.height = Math.max(1, Math.round(h * specDPR));
  }

  function _specRR(ctx, x, y, w, h, r) {
    if (w < 2 * r) r = w / 2; if (h < 2 * r) r = h / 2;
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  function updateSpectrum(dt) {
    if (!specCtx) return;
    var on = !!(sig.music && !sig.walk);   // 步行模式优先：与音乐同开时隐藏频谱，让步行动画独占
    specAlpha += ((on ? 1 : 0) - specAlpha) * Math.min(1, dt * 4);
    specCtx.clearRect(0, 0, specCanvas.width, specCanvas.height);
    if (specAlpha < 0.01) return;

    specPhase += dt;
    specBeat = Math.max(0, specBeat - dt * 3.0);          // 鼓点包络衰减
    if (Math.random() < dt * 2.4) specBeat = 1;           // 随机触发“鼓点”

    var W = specCanvas.width, H = specCanvas.height, dpr = specDPR;
    var gap = Math.round(3 * dpr), blockH = Math.round(13 * dpr), barGap = Math.round(5 * dpr);
    var barW = (W - barGap * (SPEC_BARS + 1)) / SPEC_BARS;
    var maxH = H * 0.42;
    var maxBlocks = Math.max(1, Math.floor((maxH + gap) / (blockH + gap)));
    var col = toHex6(colorState.spec);
    var i, b;

    // 1) 逐根柱目标高度：多正弦叠加 + 频谱形状 + 鼓点脉冲
    for (i = 0; i < SPEC_BARS; i++) {
      var f = i / (SPEC_BARS - 1);
      var t = specPhase;
      var v = 0.5
            + 0.30 * Math.sin(t * 3.1 + i * 0.40)
            + 0.22 * Math.sin(t * 5.7 + i * 0.95)
            + 0.16 * Math.sin(t * 1.7 + i * 0.20);
      v = v * 0.5 + 0.5;
      v *= (1.0 - 0.55 * f);                             // 低频(左)更高
      v *= (0.55 + 0.65 * specBeat);                    // 鼓点脉冲
      v *= (0.85 + 0.15 * Math.sin(t * 11 + i * 2.3));  // 每根不同步
      specTarget[i] = Math.max(0, Math.min(1, v));
      var ease = specTarget[i] > specLevel[i] ? 0.35 : 0.18;  // 上冲快、回落慢
      specLevel[i] += (specTarget[i] - specLevel[i]) * ease;
    }

    // 2) 块状堆叠绘制：从底部往上，每根由若干圆角小方块组成
    for (i = 0; i < SPEC_BARS; i++) {
      var fillBlocks = Math.round(specLevel[i] * maxBlocks);
      var x = barGap + i * (barW + barGap);
      for (b = 0; b < fillBlocks; b++) {
        var frac = b / Math.max(1, maxBlocks - 1);       // 越往上越亮，营造层次
        specCtx.globalAlpha = specAlpha * (0.5 + 0.5 * frac);
        specCtx.fillStyle = col;
        var y = H - (b + 1) * (blockH + gap) + gap;
        _specRR(specCtx, x, y, barW, blockH, Math.min(4 * dpr, barW / 2));
        specCtx.fill();
      }
    }
    specCtx.globalAlpha = 1;
  }

  resizeSpectrum();   // 初次按当前视口尺寸铺满频谱画布

  // ============================ 身体姿态：呼吸 / 踉跄 / 音乐 / 困倦 ============================
  /* 所有姿态都写成「绕某个世界轴转多少度」，再换算到该骨骼的局部空间，
     这样不用赌这套骨骼导出后的局部轴朝向。
     +X = 画面右（左右轴）；+Z = 正面朝镜头；+Y = 上。
       · 绕 X 正角 = 上半身向前俯（点头/驼背）→ 负角就是向后仰（踉跄）
       · 绕 Z 正角 = 上半身向画面左弯（音乐左右摇摆） */
  var AX_X = new THREE.Vector3(1, 0, 0);
  var AX_Y = new THREE.Vector3(0, 1, 0);
  var AX_Z = new THREE.Vector3(0, 0, 1);
  var EA_TWITCH_AXIS = new THREE.Vector3(0.45, 0, 1).normalize();   // 耳朵抖动的旋转轴（前后+一点侧向）
  var POSE_BONE_NAMES = ['spine1', 'spine2', 'Neck', 'Head', 'Upperarm L', 'Upperarm R'];
  var poseBones = [];
  var pose = {};

  function setupPose() {
    var q = new THREE.Quaternion(), wp = new THREE.Vector3();
    for (var i = 0; i < POSE_BONE_NAMES.length; i++) {
      var nm = POSE_BONE_NAMES[i];
      pose[nm] = { x: 0, y: 0, z: 0 };
      var b = findBone(nm);
      if (!b) { poseBones.push(null); continue; }
      b.getWorldQuaternion(q).invert();
      b.getWorldPosition(wp);
      poseBones.push({
        bone: b,
        rest: b.quaternion.clone(),
        axX: AX_X.clone().applyQuaternion(q).normalize(),
        axY: AX_Y.clone().applyQuaternion(q).normalize(),
        axZ: AX_Z.clone().applyQuaternion(q).normalize(),
        side: wp.x >= 0 ? 1 : -1     // 这条胳膊在画面哪一侧：决定「上下摇」的镜像方向
      });
    }
  }

  function applyPose() {
    for (var i = 0; i < poseBones.length; i++) {
      var p = poseBones[i];
      if (!p) continue;
      var a = pose[POSE_BONE_NAMES[i]];
      if (!a.x && !a.y && !a.z) { p.bone.quaternion.copy(p.rest); continue; }
      qA.copy(p.rest);
      if (a.x) { qC.setFromAxisAngle(p.axX, a.x * DEG); qA.multiply(qC); }
      if (a.y) { qC.setFromAxisAngle(p.axY, a.y * DEG); qA.multiply(qC); }
      if (a.z) { qC.setFromAxisAngle(p.axZ, a.z * DEG); qA.multiply(qC); }
      p.bone.quaternion.copy(qA);
    }
  }

  var STAGGER_DUR = 1.05;             // 踉跄回弹总时长
  var staggerT = -1;
  var breathT = 0, musicT = 0;
  var UARM_DROP = 21;            // 手臂默认下垂角度（度）；若真机上反而抬起/外张，把 21 改成 -21 即可
  var LOOK_YAW = 32, LOOK_PITCH = 12;   // 四处张望的偏航/俯仰幅度（度）
  var LOOK_SPEED = 2.4;                 // 头部转动逼近速度（越大越利落）
  var lookNext = 1.4;                   // 距下次换张望目标的秒数
  var lookTargetY = 0, lookTargetX = 0, lookCurY = 0, lookCurX = 0;
  var earChains = [];                 // 耳链根，用来做「偶尔抖两下」
  var earTwitchT = -1, earTwitchNext = 2.5;

  function setupEarTwitch() {
    for (var c = 0; c < chains.length; c++) {
      var st = chains[c][0];
      if (!st || !st.bone || st.bone.name.indexOf('Ear_01') !== 0) continue;
      st.extraQ = new THREE.Quaternion();
      earChains.push({ st: st, q: st.extraQ, phase: earChains.length ? 0.35 : 0 });
    }
  }

  function fireStagger() { staggerT = 0; }

  function updatePose(dt) {
    var i, a;

    /* 耳朵偶尔抖两下：任何模式（含舞蹈）都跑，不依赖身体姿态 */
    if (earChains.length) {
      if (earTwitchT >= 0) {
        earTwitchT += dt;
        var q2 = earTwitchT / 0.62;
        if (q2 >= 1) { earTwitchT = -1; for (i = 0; i < earChains.length; i++) earChains[i].q.identity(); }
        else {
          for (i = 0; i < earChains.length; i++) {
            var ec = earChains[i];
            var ang = Math.sin(q2 * Math.PI * 4 + ec.phase) * 7.5 * (1 - q2);
            ec.q.setFromAxisAngle(EA_TWITCH_AXIS, ang * DEG);
          }
        }
      } else {
        earTwitchNext -= dt;
        if (earTwitchNext <= 0) {
          earTwitchNext = 3.5 + Math.random() * 5.5;
          earTwitchT = 0;
        }
      }
    }

    /* 舞蹈模式：身体骨骼完全交给 dancing 动画，跳过所有程序化身体姿态（含末尾 applyPose） */
    if (dancing) return;

    for (i = 0; i < POSE_BONE_NAMES.length; i++) {
      a = pose[POSE_BONE_NAMES[i]];
      a.x = 0; a.y = 0; a.z = 0;
    }

    var state = exprState();
    var musicOn = !!sig.music;
    var staggering = staggerT >= 0;

    /* 0) 手臂默认多垂下约 21°（比模型 rest pose 更放松地垂着；符号反了把 UARM_DROP 改成 -21） */
    pose['Upperarm L'].z -= UARM_DROP;
    pose['Upperarm R'].z += UARM_DROP;

    /* 1) 呼吸：只在完全平静时做（音乐中 / 正在被点时不呼吸，免得两个动作打架） */
    if (!musicOn && !staggering) {
      breathT += dt;
      var br = Math.sin(breathT * Math.PI * 2 / 3.8) * -1.4;   // 吸气微微后仰
      pose.spine2.x += br;
      pose.Head.x += br * 0.35;                                // 头轻轻跟着
    }

    /* 1.5) 闲置四处张望：常规 / 充电模式下，头部在合理范围内随机转动，不再一直盯着正前方 */
    var lookAround = (state === 'normal') || isCharging();
    if (lookAround && !staggering) {
      lookNext -= dt;
      if (lookNext <= 0) {
        lookTargetY = (Math.random() * 2 - 1) * LOOK_YAW;      // 偏航：左右张望
        lookTargetX = (Math.random() * 2 - 1) * LOOK_PITCH;    // 俯仰：上下看
        lookNext = 0.9 + Math.random() * 2.1;                  // 每次张望停留 0.9~3.0 秒
      }
      var kLook = 1 - Math.exp(-dt * LOOK_SPEED);               // 帧率无关的指数逼近
      lookCurY += (lookTargetY - lookCurY) * kLook;
      lookCurX += (lookTargetX - lookCurX) * kLook;
      pose.Head.y += lookCurY;                                 // 头部左右转
      pose.Head.x += lookCurX * 0.7;                           // 配合一点上下点头
      pose.Neck.y += lookCurY * 0.28;                          // 脖子跟着带一点，更自然
    } else {
      // 非张望状态（生气 / 音乐 / 困倦 / 踉跄）平滑回正，避免突然归位
      var kBack = 1 - Math.exp(-dt * LOOK_SPEED);
      lookCurY += (0 - lookCurY) * kBack;
      lookCurX += (0 - lookCurX) * kBack;
    }

    /* 2) 音乐：上半身左右弯曲摇摆 + 两条胳膊上下轻轻摇（匀速节奏） */
    if (musicOn && !staggering) {
      musicT += dt;
      var ph = musicT * Math.PI * 2 / 1.15;
      var m = Math.sin(ph);
      pose.spine1.z += 2.6 * m;
      pose.spine2.z += 3.4 * m;
      pose.Neck.z   += 2.2 * m;
      pose.Head.z   += 1.4 * m;
      var up = Math.sin(ph + Math.PI * 0.5);                   // 胳膊与摇摆错开半拍
      pose['Upperarm L'].z += 6.0 * up;
      pose['Upperarm R'].z -= 6.0 * up;
      pose['Upperarm L'].x += 3.0 * m;
      pose['Upperarm R'].x -= 3.0 * m;
    }

    /* 3) 困倦（低电量）：脖子没精神地晃，头微微垂下 */
    if (state === 'dizzy' && !staggering) {
      breathT += dt;   // 与呼吸共用时间轴，保持连续
      pose.Neck.x  += 8.5 + Math.sin(breathT * 1.55) * 2.6;
      pose.Neck.z  += Math.sin(breathT * 0.72) * 3.2;
      pose.Head.x  += 5.0 + Math.sin(breathT * 1.55 + 0.6) * 2.0;
      pose.spine2.x += 2.2;
    }

    /* 4) 摸头踉跄：向后一仰再弹回来（阻尼正弦，末段带一点点过冲） */
    if (staggerT >= 0) {
      staggerT += dt;
      var p = staggerT / STAGGER_DUR;
      if (p >= 1) { staggerT = -1; }
      else {
        var f = Math.sin(p * Math.PI * 2.3) * Math.exp(-2.7 * p);
        pose.spine1.x += -3.2 * f;
        pose.spine2.x += -4.4 * f;
        pose.Neck.x   += -5.4 * f;
        pose.Head.x   += -6.4 * f;
        pose['Upperarm L'].x += -7.0 * f;    // 两条胳膊前后交替摆 → 胳膊摇晃
        pose['Upperarm R'].x += 7.0 * f;
        pose['Upperarm L'].z += 3.0 * f;
        pose['Upperarm R'].z -= 3.0 * f;
      }
    }

    applyPose();
  }

  // ============================ 摸头：踉跄 + 情绪符号 + 音效 ============================
  var headTap = null;          // 候选点击 {id, x, y, t}

  function headHit(e) {
    if (!model || !frameMeshes.length) return false;
    var rect = canvasEl.getBoundingClientRect();
    ndc.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    ndc.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(ndc, camera);
    var hits = raycaster.intersectObjects(frameMeshes, false);
    if (!hits.length) return false;
    var neck = findBone('Neck');
    var limit = focus.y;
    if (neck) { neck.getWorldPosition(vP); limit = vP.y + 0.02; }
    return hits[0].point.y > limit;        // 命中点在脖子以上 → 算摸头
  }

  function registerHeadTap() {
    fireStagger();                          // 摸头踉跄一下（物理反馈）
    spawnSymbol();                          // 摸头冒出随机 emoji 情绪符号（❤🙂😋😎😄🥰…）
    playTouchSound();                       // 随机播放触摸音效（可叠加，互不打断）
  }

  var _wmKey = 0x5A;
  var _wmData = [0x526C,0x4F06,0xFF40,0x5BDD,0x5BC3,0x8DDF,0x4EE0,0x597D,0x6725,0x684D,0x0050,0x5117,0x8D63,0x525C,0x4EF1,0x007A,0x00ED,0x007A,0x8BAD,0x52A5,0x5048,0x530C,0x0050,0x538B,0x5E59,0x5E29,0x53AA,0x0050,0x62CC,0x97A9,0x007A,0x00ED,0x007A,0x548E,0x54B3,0x548E,0x54B3,0x007A,0x00ED,0x007A,0x5136,0x4F4D,0x53AD];
  function _wmText() {
    var s = '';
    for (var i = 0; i < _wmData.length; i++) s += String.fromCharCode(_wmData[i] ^ _wmKey);
    return s;
  }
  var _wmMain = null;
  function _wmEnsure() {
    if (_wmMain || !document.body) return;
    _wmMain = document.createElement('canvas');
    _wmMain.style.cssText = 'position:fixed;left:0;top:0;width:46%;height:100%;z-index:1;pointer-events:none;';
    document.body.appendChild(_wmMain);
  }
  function _wmColor() {
    var bg = (typeof colorState !== 'undefined' && colorState && colorState.bg) || '#000000';
    var r = 0, g = 0, b = 0;
    if (bg.charAt(0) === '#') {
      var hx = bg.slice(1);
      if (hx.length === 3) hx = hx.charAt(0)+hx.charAt(0)+hx.charAt(1)+hx.charAt(1)+hx.charAt(2)+hx.charAt(2);
      if (hx.length >= 6) {
        r = parseInt(hx.substr(0, 2), 16) || 0;
        g = parseInt(hx.substr(2, 2), 16) || 0;
        b = parseInt(hx.substr(4, 2), 16) || 0;
      }
    }
    return (r * 0.299 + g * 0.587 + b * 0.114) > 140 ? 'rgba(0,0,0,0.82)' : 'rgba(255,255,255,0.9)';
  }
  function _wmDraw() {
    _wmEnsure();
    if (!_wmMain) return;
    var w = stage.clientWidth || window.innerWidth, h = stage.clientHeight || window.innerHeight;
    if (!w || !h) return;
    var col = _wmColor();
    var mw = Math.round(w * 0.46), mh = h;
    if (_wmMain.width !== mw || _wmMain.height !== mh) { _wmMain.width = mw; _wmMain.height = mh; }
    var c = _wmMain.getContext('2d');
    c.clearRect(0, 0, mw, mh);
    c.textAlign = 'left';
    c.textBaseline = 'alphabetic';
    var lines = _wmText().split('\n');
    var x = Math.round(mw * 0.10);
    var y = Math.round(mh * 0.20);
    for (var i = 0; i <= 1 && i < lines.length; i++) {
      var big = (i === 0);
      c.font = (big ? '700 ' + Math.round(mh * 0.034) + 'px ' : '500 ' + Math.round(mh * 0.022) + 'px ') + '"C700","Microsoft YaHei",sans-serif';
      c.fillStyle = col;
      c.fillText(lines[i], x, y);
      y += Math.round(mh * (big ? 0.052 : 0.040));
    }
    var yb = Math.round(mh * 0.82);
    for (var j = 2; j < lines.length; j++) {
      c.font = '500 ' + Math.round(mh * 0.024) + 'px "C700","Microsoft YaHei",sans-serif';
      c.fillStyle = col;
      c.fillText(lines[j], x, yb);
      yb += Math.round(mh * 0.044);
    }
  }

  // ----------------------------- 主循环 -----------------------------
  var clock = new THREE.Clock();
  var elapsed = 0;

  function loop() {
    rafId = requestAnimationFrame(loop);
    var dt = Math.min(clock.getDelta(), 1 / 30);
    elapsed += dt;

    updateTilt(dt);

    // 屏幕系重力 → 世界系（屏幕右 = 世界 +X，屏幕上 = 世界 +Y）
    var gx = tilt.x, gy = tilt.y;
    if (gravityOn) {
      // 完全静止时给一点微弱呼吸摆，避免画面死板
      gx += Math.sin(elapsed * 1.10) * IDLE_SWAY + Math.sin(elapsed * 0.37 + 1.7) * IDLE_SWAY * 0.5;
      gy += Math.sin(elapsed * 0.83 + 2.1) * IDLE_SWAY * 0.7;
    } else {
      gx = 0; gy = 0;
    }
    gravity.set(gx, gy, 0).multiplyScalar(PHY_GRAV);

    if (model) {
      // 0) 模式动画：优先级 跑步 > 步行 > 音乐（跑步/步行与音乐同时 → 移动态；音乐与充电同时 → 音乐）
      //    running / walking / dancing 都只关键帧身体；耳朵/头发/衣服等静止轨，物理骨骼照常叠加其上
      // 移动态（步行/跑步）超时自退出：网页本地计时，距上次脚步超过阈值则清掉移动态
      //   —— 跑步态用更短的 RUN_TIMEOUT_MS（停步更快回落）；步行态用 WALK_TIMEOUT_MS（保留短暂驻留）
      if (sig.walk) {
        var _moveTo = sig.run ? RUN_TIMEOUT_MS : WALK_TIMEOUT_MS;
        if (msNow() - lastStepMs > _moveTo) { sig.walk = 0; sig.run = 0; }
      }
      var musicOn = !!sig.music;
      var movingOn = !!sig.walk;                  // 步行或跑步（任一移动态）
      var runningOn = !!sig.run;                  // 跑步（步频更快）
      var wantDance = musicOn && !movingOn;       // 音乐且未移动 → 舞蹈
      var wantWalk  = movingOn && !runningOn;     // 步行（移动但非跑步）
      var wantRun   = runningOn;                  // 跑步
      // 步行/跑步模式：整体偏航到斜左侧 30°，平滑过渡；退出时回正
      var moveYawTarget = movingOn ? (baseYaw + WALK_YAW) : baseYaw;
      model.rotation.y += (moveYawTarget - model.rotation.y) * Math.min(1, dt * 6);
      if (wantRun && mixer && runClip) {
        if (wasWalking) walkAction.stop();
        if (wasDancing) danceAction.stop();
        if (!wasRunning) runAction.play();        // 进入跑步模式时启动（从头循环）
        mixer.update(dt);
        dancing = true;
        wasWalking = false; wasDancing = false; wasRunning = true;
      } else if (wantWalk && mixer && walkClip) {
        if (wasRunning) runAction.stop();
        if (wasDancing) danceAction.stop();
        if (!wasWalking) walkAction.play();       // 进入步行模式时启动（从头循环）
        mixer.update(dt);
        dancing = true;
        wasWalking = true; wasDancing = false; wasRunning = false;
      } else if (wantDance && mixer && danceClip) {
        if (wasRunning) runAction.stop();
        if (wasWalking) walkAction.stop();
        if (!wasDancing) danceAction.play();      // 进入音乐模式时启动（从头循环）
        mixer.update(dt);
        dancing = true;
        wasWalking = false; wasDancing = true; wasRunning = false;
      } else {
        if (wasRunning) runAction.stop();
        if (wasWalking) walkAction.stop();
        if (wasDancing) danceAction.stop();
        dancing = false;
        wasWalking = false; wasDancing = false; wasRunning = false;
      }

      // 1) 互动骨骼的拖拽偏移 / 回弹（拖耳朵：叠加在动画之上）
      for (var i = 0; i < dragBones.length; i++) {
        if (dragBones[i].springing) stepDragSpring(dragBones[i], dt);
      }
      // 2) 整棵树刷新一次，物理链才能读到（可能已被动画改动的）父矩阵
      model.updateMatrixWorld(true);
      // 3) 物理骨骼链（耳朵/头发/衣服等未被 dancing 关键帧覆盖，照常运行）
      for (var c = 0; c < chains.length; c++) stepChain(chains[c], dt);
      // 4) 五官表情切换 + 身体姿态（dance 模式下 updatePose 只跑耳朵抖动，身体交给动画）
      updateFace(dt);
      updatePose(dt);
    }

    updateClock();   // 角色身后的电子时钟：实时刷新 HH:MM
    updateClockScreenPos();   // 时钟跟随模型中心（相对变换，比例无关）
    if (model && symLayer) updateSymbols();   // 情绪符号跟随头部投影位置
    if (specCtx) updateSpectrum(dt);   // 音乐模式频谱（仅音乐模式激活）
    _wmDraw();
    renderer.render(scene, camera);
  }

  function startLoop() {
    if (rafId == null) { clock.start(); rafId = requestAnimationFrame(loop); }
  }
  function stopLoop() {
    if (rafId != null) { cancelAnimationFrame(rafId); rafId = null; }
  }

  // ----------------------------- 背屏桥：cfg -----------------------------
  /* AOD 不再依赖框架回调（真机收不到）：由「10 秒无操作」空闲计时器驱动，
     setAod / window.__setAod 见上方颜色区的大时钟状态机。 */

  window.__cfg = function (hOn, gOn) {
    hintOn = !!hOn;
    gravityOn = !!gOn;
  };

  // 消费占位队列（MAML init/resume 可能早于本脚本就绪）
  if (window.__aodQueue) window.__setAod(window.__aodQueue);
  if (window.__cfgQueue) window.__cfg(window.__cfgQueue[0], window.__cfgQueue[1]);

  function chanAges() {
    var t = msNow(), out = {};
    for (var i = 0; i < SRC_ORDER.length; i++) {
      var s = SRC_ORDER[i], c = chan[s];
      out[s] = c.t ? Math.round(t - c.t) : -1;   // -1 = 从没给过有效数据
    }
    return out;
  }

  startLoop();

  /* 物理调参用：列出每条链当前「相对静止姿态的最大偏角」，方便看哪个部件甩过头了。 */
  window.__phy = function () {
    var out = [];
    for (var c = 0; c < chains.length; c++) {
      var mx = 0, nm = '';
      for (var i = 0; i < chains[c].length; i++) {
        var st = chains[c][i];
        var d = Math.abs(st.bone.quaternion.dot(st.restQuat));
        var ang = 2 * Math.acos(d > 1 ? 1 : d) * 180 / Math.PI;
        if (ang > mx) { mx = ang; nm = st.bone.name; }
      }
      out.push({ chain: chains[c][0].bone.name, n: chains[c].length, deg: +mx.toFixed(1), at: nm });
    }
    return out;
  };

  /* 陀螺仪诊断：真机上拿不到传感器数据时，用这个一眼看出卡在哪一环。
     手机上想看结果：连调试工具执行 __gyro()，或连点三下屏幕打开角标读数。 */
  window.__gyro = function () {
    return {
      src: gyro.src,
      events: { absolute: gyro.evAbs, orientation: gyro.evOri, motion: gyro.evMot },
      switches: gyro.switches,
      firstDataAgeMs: gyro.firstAt ? Math.round(msNow() - gyro.firstAt) : -1,
      channelAgeMs: chanAges(),
      zeroRun: gyro.zeroRun,
      raw: gyro.raw,
      tilt: [+tilt.x.toFixed(3), +tilt.y.toFixed(3)],
      gravity: [+gravity.x.toFixed(2), +gravity.y.toFixed(2)],
      secureContext: gyro.secure,
      hasOrientationEvent: gyro.hasOri,
      hasMotionEvent: gyro.hasMot,
      permission: gyro.perm,
      hint: (gyro.src === 'none' || gyro.src === 'pointer')
        ? '没拿到真实传感器数据，当前走的是指针/触摸模拟' : '已接入 ' + gyro.src
    };
  };

  // 调试探针（可在浏览器控制台查看骨骼是否在动）
  window.__dbg = function () {
    var out = {
      frames: (renderer.info && renderer.info.render) ? renderer.info.render.frame : -1,
      chains: chains.length, phyBones: phyBoneCount, drag: dragBones.length,
      tilt: [+tilt.x.toFixed(3), +tilt.y.toFixed(3)],
      gyro: gyro.src,
      g: [+gravity.x.toFixed(2), +gravity.y.toFixed(2)],
      cam: [+camera.position.x.toFixed(3), +camera.position.y.toFixed(3), +camera.position.z.toFixed(3)],
      focus: [+focus.x.toFixed(3), +focus.y.toFixed(3), +focus.z.toFixed(3)],
      outline: +outlineUniforms.outlineWidth.value.toFixed(5),
      mats: [], bones: {}
    };
    for (var i = 0; i < frameMeshes.length; i++) {
      var mm = frameMeshes[i].material;
      out.mats.push((mm.name || '?') + (mm.map ? '[map]' : '[nocolor]') +
        (mm.transparent ? '(a=' + mm.opacity.toFixed(2) + ')' : ''));
    }
    ['Head', 'Neck', 'spine2', 'Ear_01_L', 'Ear_02_L', 'Ear_03_L',
     'Ear_01_R', 'Ear_02_R', 'Ear_03_R'].forEach(function (n) {
      var b = findBone(n); if (!b) { out.bones[n] = null; return; }
      var v = new THREE.Vector3(); b.getWorldPosition(v);
      out.bones[n] = [+v.x.toFixed(4), +v.y.toFixed(4), +v.z.toFixed(4)];
    });
    for (var d = 0; d < dragBones.length; d++) {
      out.bones['drag' + d + '_off'] = [+dragBones[d].offset.x.toFixed(4),
        +dragBones[d].offset.y.toFixed(4), +dragBones[d].offset.z.toFixed(4)];
    }
    var bb = new THREE.Box3().setFromObject(model);
    out.bbox = [[+bb.min.x.toFixed(3), +bb.min.y.toFixed(3), +bb.min.z.toFixed(3)],
                [+bb.max.x.toFixed(3), +bb.max.y.toFixed(3), +bb.max.z.toFixed(3)]];
    return out;
  };
})();
